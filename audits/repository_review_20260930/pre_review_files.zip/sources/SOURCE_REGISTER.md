# Source Register

## Baseline sources

### SRC-001 — Legacy UKHO-labelled candidate extraction

- Evidence class: Lead only.
- Status: Retained for historical cross-checking.
- Limitation: Third-party reproduction; no longer the project baseline.

### SRC-002 — UKHO Annual Summary of Notices to Mariners, NP247

- Authority: UK Hydrographic Office.
- Use: Subsequent implementation and amendment checking.

### SRC-003 — IMO Ships’ Routeing, 2025 Edition

- Authority: International Maritime Organization.
- Edition: Fifteenth edition, 2025.
- Sales number: II927E.
- ISBN digital: 978-92-801-1835-3.
- Project source SHA-256: `69660c0418285f81931e26a0d6e5544029572bc6b7a52623cc3a6be03234d613`.
- Evidence class: Primary.
- Status: **Authoritative project baseline reconciled.**
- Use: Part B parent inventory, individual TSS research-entity inventory and Part I mandatory reporting-system inventory.
- Repository note: The copyrighted source PDF is not committed to this public repository.

## Existing operational evidence

Existing service-source records SRC-004 onward remain available in the v0.2 workbook and audit material. They must be migrated to the v1.0 canonical TSS IDs during operational research.

## Worldwide operational source hierarchy

1. IMO instruments and publications.
2. Current routeing/reporting amendments and implementation notices.
3. UKHO Annual Summary and Notices to Mariners.
4. ADMIRALTY List of Radio Signals Volume 6.
5. ITU List IV / MARS.
6. National maritime administrations and coastguards.
7. Operating VTS authorities.
8. Official hydrographic publications.
9. Official port and waterway authorities.

## Source rule

Third-party material may identify a lead. It must not establish current operational VTS status or a final operational count by itself.


### SRC-022 — Rosmorport navigation services using VTS

- Authority: FSUE Rosmorport, North-Western Basin Branch.
- URL: https://www.rosmorport.ru/filials/spb_serv_nav/
- Evidence class: Primary operating-authority source.
- Accessed: 29 September 2026.
- Use: Current Saint Petersburg/regional eastern Gulf of Finland VTS structure, area limits, centres, technical posts and H24 operation.
- Key boundary: established vessel routes within Russian territorial waters east of 026°30'E to the relevant port-VTS boundaries.

### SRC-023 — ADMIRALTY Weekly Edition 11 of 2026, Section VI

- Authority: UK Hydrographic Office.
- Source basis: Russian Annual Notice 2026.
- URL: https://msi.admiralty.co.uk/NoticesToMariners/DownloadFile?batchId=8e8b0409-45d3-4103-8b64-bd6220063819&fileName=11wknm26.pdf&frequency=Weekly&mimeType=application%2Fpdf
- Evidence class: Current official navigational publication.
- Accessed: 29 September 2026.
- Use: Saint Petersburg Coastal VTS area, Sector 1/2 split, VHF channels and repeater stations at Gogland and Sommers.

### SRC-024 — Fintraffic Hanko VTS area

- Authority: Fintraffic Vessel Traffic Services.
- URL: https://mastersguide.fintraffic.fi/en/print/pdf/node/64
- Evidence class: Primary operating-authority source.
- Current PDF publication: 2026.
- Accessed: 29 September 2026.
- Use: Hanko VTS boundary coordinates and operating procedures.

### SRC-025 — Estonian Transport Administration VTS / GOFREP

- Authority: Estonian Transport Administration (Transpordiamet).
- URL: https://www.transpordiamet.ee/laevaliikluse-korraldamine
- Evidence class: Primary national authority source.
- Accessed: 29 September 2026.
- Use: Separation of Estonian VTS and GOFREP areas, Western VTS entry at the reporting line beginning at Kõpu, working channels and participation rules.

### SRC-026 — Swedish Maritime Administration VTS directory

- Authority: Sjöfartsverket.
- URL: https://www.sjofartsverket.se/sv/om-oss/kontakta-oss/vessel-traffic-service-vts/
- Evidence class: Primary national VTS authority source.
- Updated: 24 February 2026.
- Accessed: 29 September 2026.
- Use: Current Swedish VTS-area inventory.

### SRC-027 — Traficom decision establishing current Finnish VTS areas

- Authority: Finnish Transport and Communications Agency Traficom.
- Document: TRAFICOM/124393/05.01.24/2024.
- URL: https://traficom.fi/sites/default/files/media/regulation/Decision_Establishment_of_VTS_1.pdf
- Evidence class: Primary statutory/administrative source.
- Accessed: 29 September 2026.
- Use: Current Bothnia VTS boundary, including Ritgrund and the territorial-sea limit.

### SRC-028 — Fintraffic Bothnia VTS area

- Authority: Fintraffic Vessel Traffic Services.
- URL: https://mastersguide.fintraffic.fi/en/print/pdf/node/55
- Evidence class: Primary operating-authority source.
- Current PDF publication: 2026.
- Accessed: 29 September 2026.
- Use: Current Bothnia VTS area description, VHF 67 and advance-report procedure for Finland-bound traffic via the Quark.

### SRC-029 — Fintraffic monitoring of international waters

- Authority: Fintraffic Vessel Traffic Services Ltd.
- URL: https://www.fintraffic.fi/sv/node/254
- Evidence class: Primary operating-authority source.
- Accessed: 29 September 2026.
- Use: GOFREP and Åland Sea TSS monitoring distinction; confirms South Åland Sea monitoring and states that the Åland Sea area has no obligatory vessel reporting system.

### SRC-030 — Swedish Transport Agency Baltic SRS list

- Authority: Transportstyrelsen.
- URL: https://www.transportstyrelsen.se/sv/sjofart/sjotrafik-och-hamnar/sjotrafikrapporteringssystem-srs/
- Evidence class: Primary national authority source.
- Updated: 9 June 2026.
- Accessed: 29 September 2026.
- Use: Current mandatory SRS inventory for the Baltic Sea: SOUNDREP, BELTREP, GOFREP and GDANREP.

### SRC-031 — South Åland Sea TSS Master's Guide

- Authority: Fintraffic Vessel Traffic Services Ltd.
- URL: https://mastersguide.fintraffic.fi/index.php/sv/node/104
- Evidence class: Primary operating-authority source.
- Accessed: 29 September 2026.
- Use: Confirms South Åland Sea TSS monitoring by Åland Sea Traffic from the Western Finland Vessel Traffic Centre, AIS monitoring, VHF 16 contact and violation reporting.

### SRC-032 — TSFS 2026:60 VTS/SRS regulations

- Authority: Swedish Transport Agency.
- URL: https://www.transportstyrelsen.se/sv/om-oss/dina-rattigheter-lagar-och-regler/forfattningssamling/ts-foreskrifter-i-nummerordning/2026/details?RuleNumber=2026%3A60&ruleprefix=TSFS
- Evidence class: Primary national regulatory source.
- Adopted: 27 May 2026.
- Enters into force: 1 October 2026.
- Accessed: 29 September 2026.
- Use: Near-term Swedish VTS/SRS regulatory cross-check. Does not create a Kalmarsund or Öland offshore VTS area.

### SRC-033 — Swedish Ufs A, monitoring of TSS

- Authority: Swedish Maritime Administration (Sjöfartsverket).
- URL: https://ufs.sjofartsverket.se/pdf/Ufs_A_en.pdf
- Evidence class: Primary national navigational publication.
- Accessed: 29 September 2026.
- Use: Distinguishes TSS monitoring from VTS. States that Off Falsterborev and The Sound are monitored by Sound VTS and the remaining Swedish TSS by Sweden Traffic.

### SRC-034 — Navigation through Danish Waters

- Authority: Danish Maritime Authority.
- URL: https://www.soefartsstyrelsen.dk/Media/637977139358837038/Navigation%20through%20Danish%20Water%20version%2015%20%28SEP%202022%29.pdf
- Evidence class: Primary national navigation guide.
- Accessed: 29 September 2026.
- Use: Treats Bornholmsgat and Adlergrund as Baltic routeing measures and separately identifies the Danish VTS/SRS operational areas.

### SRC-035 — VTS Zatoka Gdańska

- Authority: Maritime Office in Gdynia.
- URL: https://www.umgdy.gov.pl/en/marine-safety/vts-zatoka-gdanska-en/
- Evidence class: Primary operating-authority source.
- Accessed: 29 September 2026.
- Use: VTS area, H24 operation, VHF 71, direct identification of TSS EAST and TSS WEST, and confirmation that the VTS area's external limits are those of compulsory GDANREP.

### SRC-036 — VTS Ławica Słupska / VTS Slupska Bank

- Authority: Maritime Office in Gdynia.
- URL: https://www.umgdy.gov.pl/en/marine-safety/vts-zatoka-gdanska-en/vts-slupska-bank/
- Evidence class: Primary operating-authority source.
- Accessed: 29 September 2026.
- Use: Direct confirmation that VTS Ławica Słupska supervises vessel traffic in the Słupska Bank TSS area; H24 duty service and VHF 73/16.

### SRC-037 — BSH VTS Guide Germany, VTS Centre Warnemünde extract

- Authority: German Federal Maritime and Hydrographic Agency (BSH).
- URL: https://linchart60.bsh.de/chartserver/pdf_version/VTS-Guide_from_S-127_Extract.pdf
- Evidence class: Primary official VTS publication.
- Accessed: 29 September 2026.
- Use: Current overview chart of VTS Centre Warnemünde sectors, including the Sassnitz Traffic service area.

### SRC-038 — BSH NfS 30-31/2021, TSS Adlergrund

- Authority: German Federal Maritime and Hydrographic Agency (BSH) / WSA Ostsee.
- URL: https://www2.bsh.de/daten/NFS/NfS2021/nfs-heft30-31-2021.pdf
- Evidence class: Primary official navigational notice.
- Accessed: 29 September 2026.
- Use: Direct operational reference to VTS Warnemünde / Sassnitz Traffic for activity within TSS Adlergrund. Used with the current BSH VTS-area chart, not by itself, to establish present association.

### SRC-039 — Navigation through Danish Waters, version 16.0 (2025)

- Authority: Danish Maritime Authority.
- URL: https://www.soefartsstyrelsen.dk/Media/638743469510433298/Navigation%20through%20Danish%20Water%20version%2016.0%202025.pdf
- Evidence class: Primary national navigation guide.
- Edition: Version 16.0, 2025.
- Accessed: 29 September 2026.
- Use: Current routeing context for South of Gedser, North of Rügen, In The Sound and Off Falsterborev, plus the SOUNDREP operational-area chart.

### SRC-040 — German Traffic Regulations for Navigable Maritime Waterways, English version

- Authority source: German maritime administration material hosted by Deutsche Flagge.
- URL: https://www.deutsche-flagge.de/de/redaktion/dokumente/rechtsvorschriften/seeschstro_engl.pdf
- Evidence class: Primary/current regulatory source.
- Accessed: 29 September 2026.
- Use: Current Kieler Förde reporting requirements. Assigns VTS Centre Travemünde / Kiel Traffic on VHF 67 and requires reports before and when passing Kiel Lighthouse.

### SRC-041 — Sjöfartsverket VTS Göteborg boundary

- Authority: Swedish Maritime Administration (Sjöfartsverket).
- URL: https://www.sjofartsverket.se/en/services/pilotage/pilot-area-gothenburg/nautical-information/communication/
- Evidence class: Primary operating-authority source.
- Accessed: 30 September 2026.
- Use: Current Göteborg VTS boundary. Southern boundary is latitude 57°31.9'N on 30 September 2026; this confirms TSS Fladen, around 57°13'N–57°15'N, lies outside the VTS area.
- Note: A published boundary amendment takes effect 1 October 2026, moving the southern limit to about 57°30.6'N. This does not affect the Fladen conclusion.

### SRC-042 — NCSR 10/INF.7, Denmark and Sweden Route S experience

- Submitters: Denmark and Sweden; hosted by Danish Maritime Authority.
- URL: https://www.soefartsstyrelsen.dk/Media/638197316856841051/NCSR%2010-INF.7%20-%20Experience%20gained%20from%20the%20establishment%20of%20traffic%20separation%20schemes%20and%20other%20routeing...%20%28Denmark%20and%20Sweden%29.pdf
- Evidence class: Primary intergovernmental submission / official administration source.
- Accessed: 30 September 2026.
- Use: Explicit statement that TSS Entrance to the Sound is situated within mandatory SOUNDREP, operated by Sound VTS. Also documents Route S and the new TSS Lilla Middelgrund.

### SRC-043 — MCA MGN 610 (M+F) Amendment 1, SOLAS chapter V guidance

- Authority: UK Maritime and Coastguard Agency.
- URL: https://www.gov.uk/government/publications/mgn-610-mf-amendment-1-solas-chapter-v-guidance-on-the-merchant-shipping-safety-of-navigation-regulations-2020/mgn-610-mf-amendment-1-navigation-solas-chapter-v-guidance-on-the-merchant-shipping-safety-of-navigation-regulations-2020
- Evidence class: Primary national guidance.
- Published/updated: 2025 page version checked on 30 September 2026.
- Use: Confirms WETREP remains a mandatory IMO ship reporting system, with a reporting area extending from southern Portugal to the Shetland Islands; separately lists UK voluntary reporting schemes including the Isles of Scilly.

### SRC-044 — IMO Resolution MSC.190(79), WETREP

- Authority: International Maritime Organization.
- URL: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC.190%2879%29.pdf
- Evidence class: Primary adopted IMO instrument.
- Adopted: 6 December 2004.
- Accessed: 30 September 2026.
- Use: Establishes the mandatory West European Tanker Reporting System (WETREP) in the Western European PSSA and defines participating ship categories and system geography.

### SRC-045 — COLREG.2/Circ.66/Corr.1 Amended traffic separation schemes, corrigendum (corrected annex 3 'Off Friesland')

- Authority: IMO Maritime Safety Committee.
- URL: https://mindev.gov.ua/storage/app/sites/1/uploaded-files/colreg2-circ66-corr1-corrigendum-secretariat.pdf
- Evidence class: Tier 1.
- Edition or date: 20 May 2016 (Circ.66 amendments implemented 1 June 2015).
- Accessed: 29 September 2026.
- Use (B10): Location of East Friesland TSS western boundary (positions 83, 84, 95, 99 at about 54 02'-54 06'N, 005 07'-005 10'E)
- Locator: Annex, East Friesland scheme paras (u)-(w) (government mirror).
- Passage: "Existing position 32 is shifted east to new position (84) 54 03'.26 N 005 08'. 65 E"

### SRC-046 — Scheepvaartreglement territoriale zee (BWBR0007914), Bijlage 1 Aanloopgebieden, art. 1, 2 and 5a

- Authority: Kingdom of the Netherlands (wetten.overheid.nl).
- URL: https://wetten.overheid.nl/BWBR0007914/
- Evidence class: Tier 1.
- Edition or date: Version in force from 1 January 2025 (consulted 29-09-2026).
- Accessed: 29 September 2026.
- Use (B10): Complete list of statutory approach areas in the Dutch territorial sea (Eemsmonding, Brandaris, Den Helder, IJmuiden, Scheveningen, Rotterdam, Scheldemonden); IJmuiden approach area is the territorial sea within a 12 nm arc from 52 27'.9N 004 32'.1E; Rotterdam approach area boundary follows buoys MN3, MN2, MNW2, MNW3-MW4, MW5 (i.e. the inner ends of the Maas TSSs); art. 5a permits ministerial reporting systems in the territorial sea
- Locator: Bijlage 1 (d) and (f); art. 5a.
- Passage: "vandaar in een zeewaarts gerichte boog met een straal van 12 zeemijlen gerekend vanuit het referentiepunt"

### SRC-047 — Berichten aan Zeevarenden / Notices to Mariners week 41-2025, BaZ 261(P)/25 'Noordzee. TSS Off Texel en TSS Off Vlieland' (VTS Off Texel) and ODAS buoy entries 'near TSS off Botney Ground'

- Authority: Dienst der Hydrografie (Netherlands Hydrographic Service).
- URL: https://www.defensie.nl/site/binaries/site-content/collections/baz-weekly-editions/2025/41/wkly_y2025_w41_baz257_265.pdf
- Evidence class: Tier 3.
- Edition or date: 9 October 2025 (VTS effective 3 November 2025 14.00 CET).
- Accessed: 29 September 2026.
- Use (B10): Boundary of VTS Off Texel (northernmost 53 37.10N, westernmost 004 21.80E) showing it excludes East Friesland (about 54 02'N+) and Off Botney Ground (ODAS buoys 'near TSS off Botney Ground' at about 53 22-23'N 003 07-08'E)
- Locator: Page 8, notice *261(P)/25; buoy list near p.20.
- Passage: "To enhance the safety of maritime traffic in the traffic separation schemes off the coast of Texel and Vlieland ... a VESSEL TRAFFIC SERVICE SECTOR will be established."

### SRC-048 — Vessel Traffic Monitoring (VTMon)

- Authority: Kustwacht Nederland (Netherlands Coastguard).
- URL: https://kustwacht.nl/hulpverlening/vtm/
- Evidence class: Tier 2.
- Edition or date: Undated web page, consulted 29 September 2026.
- Accessed: 29 September 2026.
- Use (B10): Coastguard monitoring of North Sea traffic is Vessel Traffic Monitoring, a distinct task, not a VTS; recorded as a lead only
- Locator: Page body.
- Passage: "Vessel Traffic Monitoring (VTMon) is een nieuwe taak van de Kustwacht."

### SRC-049 — IMO_2025_Mandatory_Reporting_Systems.csv (IMO Ships' Routeing 2025 Part I inventory, VRS-0001 to VRS-0023)

- Authority: Global VTS project.
- URL: data/authoritative/IMO_2025_Mandatory_Reporting_Systems.csv
- Evidence class: Tier 1.
- Edition or date: Ships' Routeing 2025 Edition baseline.
- Accessed: 29 September 2026.
- Use (B10): No Part I mandatory reporting system is located in Dutch waters; only WETREP (VRS-0005) and CALDOVREP (VRS-0008) required geographic testing for group P
- Locator: Rows I-I/1 to I-I/23.
- Passage: "n/a (project dataset)"

### SRC-050 — Besluit routerings- en meldingssystemen voor schepen in volle zee voor de Nederlandse kust (BWBR0008956)

- Authority: Kingdom of the Netherlands (wetten.overheid.nl).
- URL: https://wetten.overheid.nl/BWBR0008956/
- Evidence class: Tier 1.
- Edition or date: Version in force from 18 May 2005 (a pending amendment without commencement date is flagged).
- Accessed: 29 September 2026.
- Use (B10): Legal basis for routeing and reporting systems outside the Dutch territorial sea, to be set by ministerial regulation
- Locator: Artikel 2.
- Passage: "buiten de Nederlandse territoriale zee, overeenkomstig richtlijnen en criteria van de Internationale Maritieme Organisatie, routeringssystemen en meldingssystemen worden vastgesteld"

### SRC-051 — Regeling routerings- en meldingssystemen voor schepen in volle zee voor de Nederlandse kust (BWBR0033648)

- Authority: Minister van Infrastructuur en Milieu / Waterstaat (wetten.overheid.nl; original Stcrt. 2013, 19233).
- URL: https://wetten.overheid.nl/BWBR0033648/
- Evidence class: Tier 1.
- Edition or date: Version in force from 6 July 2022 (original in force 1 August 2013).
- Accessed: 29 September 2026.
- Use (B10): The only ministerial regulation under P-S16: contains the mandatory tanker route North Hinder - German Bight (§2) and areas to be avoided (§3) but no reporting system; supports 'no national mandatory reporting' for the EEZ-located schemes
- Locator: Inhoudsopgave §1-§4; Stcrt. 2013, 19233 artikelen 2-8.
- Passage: "§ 2 Routeringssysteem Noord Hinder – Duitse Bocht ... § 3 Gebieden die dienen te worden gemeden"

### SRC-052 — COLREG.2/Circ.59 New and amended existing traffic separation schemes (annex 4: Mandatory route for tankers from North Hinder to the German Bight)

- Authority: IMO Maritime Safety Committee.
- URL: https://cimrc.shmtu.edu.cn/_upload/article/files/63/dc/35c66be74d12873254dc88a2ef00/465d5392-0ba5-4f33-8e61-a48e3499b1b3.pdf
- Evidence class: Tier 1.
- Edition or date: 31 October 2007.
- Accessed: 29 September 2026.
- Use (B10): Off Botney Ground forms part of the recommended western route for deep-draught tankers exempted from the southern part of the mandatory tanker route (routeing, not reporting)
- Locator: Annex 4, page 2.
- Passage: "Shipmasters should enter this deviation in the ships' log."

### SRC-053 — COLREG.2/Circ.67 New and amended traffic separation schemes (annex 3: 'In the approaches to Hook of Holland and at North Hinder', consolidated and superseding B-II/10)

- Authority: IMO Maritime Safety Committee.
- URL: https://cimrc.shmtu.edu.cn/_upload/article/files/63/dc/35c66be74d12873254dc88a2ef00/65c44f78-cf76-44e1-aa8a-6727556bcb18.pdf
- Evidence class: Tier 1.
- Edition or date: 20 May 2016; implemented 0000 UTC 1 June 2017.
- Accessed: 29 September 2026.
- Use (B10): Current geometry of Maas North, Maas North-west, Maas West Inner, Maas West Outer, North Hinder North, North Hinder South and Off North Hinder; used for all distance and boundary tests in B10/B11
- Locator: Annex 3, pages 1-6 (third-party mirror of the IMO circular; text checked against the IMO document header).
- Passage: "This amended routeing system consolidates and supersedes existing TSS "In the approaches to Hook of Holland and at North Hinder" (part B, page II/10)"

### SRC-054 — Port Information Guide, Port of Rotterdam, version 2026.1

- Authority: Port of Rotterdam Authority.
- URL: https://www.portofrotterdam.com/sites/default/files/2026-02/port-information-guide.pdf
- Evidence class: Tier 4.
- Edition or date: January 2026 (rev. 2026-01-17; file dated 2 Feb 2026).
- Accessed: 29 September 2026.
- Use (B10): Rotterdam VTS service name, location and service-area extent (38 nm seawards of the port entrance); VTS report on passing first calling-in point
- Locator: Page 18 'Nautical services'; page 4 'In port reports'.
- Passage: "Service Area Description: Extending 38 nautical miles seawards of the port entrance"

### SRC-055 — Procedure VHF-communicatie VTS en HCC, versie 2.0 (incl. Bijlage 1 VHF-kanalen and Bijlage 2 Toepassingsgebied sector chart)

- Authority: Port of Rotterdam Authority (Havenmeester van Rotterdam, DHMR).
- URL: https://www.portofrotterdam.com/sites/default/files/2026-05/procedure-vhf-communicatie-vts-hcc-2026_0.pdf
- Evidence class: Tier 2.
- Edition or date: Februari 2026, versie 2.0.
- Accessed: 29 September 2026.
- Use (B10): Current VTS sectors (Maas Aanloop VHF 1, Pilot Maas VHF 2, Maasmond VHF 3); arrival report from sea on VHF 1; official sector chart showing the Maas West Inner/Outer, Maas North-west and Maas North lanes within the area shaded as Sector Maas Approach
- Locator: Section 2 Toepassingsgebied; section 10; Bijlage 1 (p.8); Bijlage 2 chart (p.9). PDF is image-only; read visually.
- Passage: "Vanuit zee, VHF-kanaal 1 (sector Maas Aanloop)."

### SRC-056 — Beleidsregel Procedure VHF-communicatie VTS en HCC 2026 (Staatscourant 2026, 8272; reissued 8272-n1)

- Authority: Havenmeester van Rotterdam (Staatscourant).
- URL: https://zoek.officielebekendmakingen.nl/stcrt-2026-8272.html
- Evidence class: Tier 1.
- Edition or date: Adopted and in force 20 February 2026; published 3 March 2026.
- Accessed: 29 September 2026.
- Use (B10): Legal publication of the Rotterdam VTS procedure; states it applies in the 'aanloopgebied Rotterdam' and port area, while the procedure's scope is the VTS area on the Bijlage 2 chart
- Locator: Artikel 1; Bijlage, section 2.
- Passage: "Met ingang van 1 februari 2026 is in het aanloopgebied Rotterdam en het Rotterdamse havengebied de regeling ... van kracht."

### SRC-057 — Marifoonblokindeling VTS-Scheldegebied, versie 4.0 (folder with sector chart and outer-limit coordinates)

- Authority: Gemeenschappelijk Nautisch Beheer / Kustwacht (Belgium).
- URL: https://kustwacht.be/sites/default/files/legacy_files/marifoonblokindeling_2.pdf
- Evidence class: Tier 4.
- Edition or date: August 2014 (PDF created 4 Aug 2014).
- Accessed: 29 September 2026.
- Use (B11): Seaward limit of the Scheldt VTS area (Wandelaar approach / Steenbank) at about 51 23.6'N 002 19.2'E, 51 25.95'N 002 27.5'E, 51 28.75'N 002 56'E, 51 34.6'N 003 08.38'E, 51 50'N 003 08.38'E: North Hinder South and Off North Hinder lie outside. Dated; chart marked not for navigation
- Locator: Page 2 chart.
- Passage: "kaartje niet voor navigatiedoeleinden"

### SRC-058 — MGN 364 (M+F) Navigation: Traffic Separation Schemes - Application of Rule 10 and Navigation in the Dover Strait

- Authority: Maritime and Coastguard Agency (UK).
- URL: https://assets.publishing.service.gov.uk/media/5e2efbc840f0b62c47c5466f/MGN_364_all_tagged.pdf
- Evidence class: Tier 2.
- Edition or date: Current MCA guidance (refers to Ships' Routeing 9th edition 2008); consulted 29 September 2026.
- Accessed: 29 September 2026.
- Use (B11): CALDOVREP (VRS-0008) eastern reporting line North Foreland - France/Belgium border lies south-west of North Hinder South and Off North Hinder, so neither is inside CALDOVREP
- Locator: Section 3 (reporting); 4.7.
- Passage: "call Dover Coastguard via VHF Ch.11 not later than crossing a line drawn from North Foreland Light (51o 23'N; 001o 27'E) to the border between France and Belgium"

### SRC-059 — NL NtM 183/17, correction to HP1 (Netherlands hydrographic publication): section '15 - TSS Off North Hinder'

- Authority: Dienst der Hydrografie.
- URL: https://www.defensie.nl/site/binaries/site-content/collections/baz-weekly-editions/2017/22/blck_hp1_y2017_baz183.pdf
- Evidence class: Tier 3.
- Edition or date: 2017 (week 22).
- Accessed: 29 September 2026.
- Use (B11): Historical: the Dutch hydrographic guide gave no VTS or reporting information for TSS Off North Hinder in 2017 (not evidence of absence)
- Locator: Page 1.
- Passage: "15 – TSS Off North Hinder No particular information available."

### SRC-060 — COLREG.2/Circ.64 New and amended existing traffic separation schemes (annex 1: 'In the approaches to IJmuiden')

- Authority: IMO Maritime Safety Committee.
- URL: https://fma.fo/wp-content/uploads/2016/09/2013_02_Nautical_COLREG.2-Circ.64_New-and-amended-Existing-Traffic-Separation-Schemes.pdf
- Evidence class: Tier 1.
- Edition or date: 4 December 2012; implemented 0000 UTC 1 August 2013.
- Accessed: 29 September 2026.
- Use (B11): Positions of IJmuiden West Inner TSS (points 1-21), used to test position relative to the 12 nm VTS area
- Locator: Annex 1, page 1 (mirror copy hosted by Faroe Islands Maritime Authority).
- Passage: "IJmuiden West Inner traffic separation scheme (a) A separation zone to the north of the IJmuiden-geul is bounded by a line connecting the following geographical positions"

### SRC-061 — Regeling aanwijzing bevoegde autoriteiten Scheepvaartreglement territoriale zee (BWBR0008644)

- Authority: Minister van Verkeer en Waterstaat (wetten.overheid.nl).
- URL: https://wetten.overheid.nl/BWBR0008644/
- Evidence class: Tier 1.
- Edition or date: Version in force from 1 January 2024.
- Accessed: 29 September 2026.
- Use (B11): Competent authorities: Rotterdam approach area = havenmeester van Rotterdam; IJmuiden approach area = directeur Centraal Nautisch Beheer Noordzeekanaalgebied; territorial sea outside approach areas = directeur Kustwacht
- Locator: Artikel 1, onderdelen b, d, g.
- Passage: "d. voor het aanloopgebied IJmuiden: de directeur van het Centraal Nautisch Beheer Noordzeekanaalgebied"

### SRC-062 — Regulations for VTS Communication and the supporting VHF maritime radio-telephone channels (Regeling communicatie VTS en overige VHF-diensten en kanalen), version 2.0, NL/EN

- Authority: Centraal Nautisch Beheer Noordzeekanaalgebied (published by Port of Amsterdam).
- URL: https://www.portofamsterdam.com/sites/default/files/2025-09/2025-479_VTS%20communicatieregeling%202.0%20def_NLEN_rev.pdf
- Evidence class: Tier 2.
- Edition or date: 10 September 2025; in force 30 September 2025.
- Accessed: 29 September 2026.
- Use (B11): VTS area of the North Sea Canal Area: approaches to IJmuiden = territorial sea within 12 nm of the breakwater heads incl. extended IJ-geul; arrival report at 12 nm to Sector IJmuiden VHF 61; IJmuiden Approaches VHF 7 is a supporting information-only channel; Appendix I chart
- Locator: Scope of application (p.4); Section B.1 (p.6); Section 8 (p.8); Appendix I (p.10).
- Passage: "the approaches to IJmuiden, defined as the section of the Territorial Sea (including Anchorages 6, 7, and 8) within a 12-nautical-mile radius of the seaward ends of the IJmuiden breakwaters"

### SRC-063 — Scheepvaartreglement territoriale zee (BWBR0007914)

- Authority: Kingdom of the Netherlands (wetten.overheid.nl).
- URL: https://wetten.overheid.nl/BWBR0007914
- Evidence class: Tier 1.
- Edition or date: Version geldend van 01-01-2025 t/m heden, consulted 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B12): Statutory list of the seven Dutch aanloopgebieden (Eemsmonding, Brandaris, Den Helder, IJmuiden, Scheveningen, Rotterdam, Scheldemonden) with limits; IJmuiden area is a 12 nm arc from reference point 52°27.9'N 004°32.1'E; Brandaris area is the Terschelling zeegat; Den Helder area bounded by Marsdiep buoys. Art. 5(1): ships of 300 GT or more or carrying dangerous/polluting goods report before entering the Dutch territorial sea on a VHF channel designated by ministerial regulation.
- Locator: Art. 2(d)-(e), art. 5, Bijlage 1.
- Passage: "meldt zich voordat hij de Nederlandse territoriale zee binnenvaart op het bij ministeriële regeling aangewezen marifoonkanaal aan de bevoegde autoriteit."

### SRC-064 — Resolution MSC.190(79) Mandatory ship reporting system in the Western European PSSA (WETREP)

- Authority: IMO (archive copy, University of Hawaii Jon Van Dyke collection).
- URL: https://scholarspace.manoa.hawaii.edu/server/api/core/bitstreams/0e352943-f5a1-4212-99ff-364902266ba1/content
- Evidence class: Tier 1.
- Edition or date: Adopted 6 Dec 2004; in force 1 Jul 2005.
- Accessed: 29 September 2026.
- Use (B12): WETREP (VRS-0005) area: North Sea limits run from the Belgium/Netherlands border (point 19) to the UK east coast at 52°12'N (point 20) and from the UK coast at 58°30'N; Dutch, German and UK North Sea waters off the Humber are outside.
- Locator: Annex 1 para 2.1, points 1 and 19-20.
- Passage: "19 (B) 51° 22'25" N ... 003° 21'52".5 E (border between Band NL) 20 (UK) 52° 12' N UK east coast"

### SRC-065 — Verkeerscentrales

- Authority: Kustwacht Nederland.
- URL: https://kustwacht.nl/maritieme-organisaties/verkeerscentrales/
- Evidence class: Tier 2.
- Edition or date: Undated web page, accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B12): VTS in the Netherlands is provided by traffic centres serving routes to/from ports; distinguishes them from the Coastguard Centre.
- Locator: Page body.
- Passage: "Het coördineren en begeleiden van scheepvaart wordt Vessel Traffic Service (VTS) genoemd."

### SRC-066 — Regeling meldingen en communicatie scheepvaart (BWBR0031567)

- Authority: Kingdom of the Netherlands (wetten.overheid.nl).
- URL: https://wetten.overheid.nl/BWBR0031567
- Evidence class: Tier 1.
- Edition or date: Version geldend van 27-03-2026 t/m heden.
- Accessed: 29 September 2026.
- Use (B12): Competent authorities per aanloopgebied (IJmuiden: Havenmeester van Amsterdam; Den Helder: Rijkshavenmeester Den Helder; Brandaris: Havenmeester van Harlingen) and Director Kustwacht Nederland for the territorial sea outside the approach areas (table for anchorages/loading installations); VHF channels are those published by the competent authority (art. 20). The channel designation for STZ art. 5(1) was not located.
- Locator: Art. 20; Bijlage behorend bij artikel 2.
- Passage: "voor de territoriale zee, behoudens de aanloopgebieden Directeur Kustwacht Nederland"

### SRC-067 — AnlBV Anhang (zu § 1 Abs. 1 Nr. 1.17): chart defining the Innere Deutsche Bucht, in Zwölfte Verordnung zur Änderung seeverkehrsrechtlicher Vorschriften

- Authority: Bundesgesetzblatt (official gazette), copy hosted by OffeneGesetze.de.
- URL: https://media.offenegesetze.de/bgbl1/2005/bgbl1_2005_47.pdf#page=33
- Evidence class: Tier 1.
- Edition or date: BGBl. I 2005 Nr. 47, p. 2297, 10 Aug 2005 (still the Anhang cited by the current AnlBV).
- Accessed: 29 September 2026.
- Use (B13): Statutory chart: Inner German Bight = area covered by German Bight Traffic VHF channel 80, bounded seaward by a dashed line which (on the 2005 chart) runs near 7°18'E north of the TSS, then WSW to cross TSS Terschelling-German Bight at about 6°16'-6°22'E; Jade Approach and Elbe Approach lie well inside; only the easternmost end of GBWA lies inside. Also shows the territorial sea boundary.
- Locator: p. 2297, chart legend and geometry (read by rendering the page; longitudes estimated from the chart graticule, about +/-2').
- Passage: "Innere Deutsche Bucht im Sinne der Nummer 1.17 der Anlage ist der Bereich, der durch den UKW-Kanal 80 abgedeckt wird und in der Karte dargestellt ist."

### SRC-068 — Anlaufbedingungsverordnung (AnlBV), Anlage (zu § 1 Abs. 1), current consolidated text

- Authority: Federal Republic of Germany (BMJ / gesetze-im-internet.de).
- URL: https://www.gesetze-im-internet.de/anlbv_2004/anlage.html
- Evidence class: Tier 1.
- Edition or date: Current consolidated text accessed 29 Sep 2026 (text refers to Verordnung (EU) 2019/1239 and BMDV, so post-2019 consolidation).
- Accessed: 29 September 2026.
- Use (B13): National statutory entry report to VTS German Bight Traffic for ships over 300 GT entering the Inner German Bight, expressly regardless of use of TSS German Bight Western Approach; traffic in the Inner German Bight monitored under maritime traffic safety; Jade Approach pilot transfer position lies in the Inner German Bight outside the territorial sea; mandatory use of GBWA by large tankers.
- Locator: Anlage Nr. 1.17, 3.1, 5.1, 6, 8.
- Passage: "unabhängig davon, ob das Verkehrstrennungsgebiet „German Bight Western Approach“ benutzt wird, beim Passieren des Meridians 007° 10' E | 5.1 Der Schiffsverkehr wird im Rahmen der maritimen Verkehrssicherung überwacht."

### SRC-069 — ELWIS - Verkehrszentralen

- Authority: Generaldirektion Wasserstraßen und Schifffahrt (ELWIS).
- URL: https://www.elwis.de/DE/Seeschifffahrt/Verkehrs-und-Sicherheitsmanagement/Verkehrszentralen/Verkehrszentralen-node.html
- Evidence class: Tier 2.
- Edition or date: Undated web page, accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B13): Official list of all nine German VTS centres and their VTS sectors/call signs: Wilhelmshaven (German Bight Traffic 16/79/80, Jade Traffic, North Coast Traffic); Cuxhaven (German North Sea Traffic 16/11, West Coast Traffic, Cuxhaven Elbe Traffic 16/71); VTS centres described as Vessel Traffic Service Center.
- Locator: Verkehrszentrale Wilhelmshaven; Verkehrszentrale Cuxhaven.
- Passage: "Verkehrszentrale Wilhelmshaven (Externer Link) Seegebiet zwischen der Ems und Elbe sowie der Jade bis Wilhelmshaven VTS-Sector and call sign VHF-Channel Telephon German Bight Traffic 16/79/80"

### SRC-070 — ELWIS - Maritime Verkehrssicherung

- Authority: Generaldirektion Wasserstraßen und Schifffahrt (ELWIS).
- URL: https://www.elwis.de/DE/Seeschifffahrt/Verkehrs-und-Sicherheitsmanagement/Verkehrszentralen/Maritime-Verkehrssicherung/Maritime-Verkehrssicherung-node.html
- Evidence class: Tier 2.
- Edition or date: Stand: 18 Aug 2017.
- Accessed: 29 September 2026.
- Use (B13): German Verkehrszentralen are the VTS established under SOLAS V/12.
- Locator: Page body.
- Passage: "Die WSV hat die Umsetzung der Verpflichtung nach Regel 12 "Verkehrssicherungsdienste", Kapitel V, SOLAS durch die Einrichtung von Verkehrszentralen umgesetzt."

### SRC-071 — Verkehrszentralen (WSA Weser-Jade-Nordsee)

- Authority: Wasserstraßen- und Schifffahrtsamt Weser-Jade-Nordsee (WSV).
- URL: https://www.wsa-weser-jade-nordsee.wsv.de/Webs/WSA/Weser-Jade-Nordsee/DE/Schifffahrt/Verkehrszentralen/verkehrsundrevierzentralen_node.html
- Evidence class: Tier 2.
- Edition or date: Undated web page, accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B13): VTS Centre Wilhelmshaven operates German Bight Traffic (with North Coast Traffic) and Jade Traffic and monitors the inner German Bight from Borkum to Helgoland; 24-hour operation.
- Locator: Verkehrszentrale Wilhelmshaven.
- Passage: "Von Wilhelmshaven aus erfolgt die Überwachung des Schiffsverkehrs der inneren deutschen Bucht von Borkum bis Helgoland und der Jade."

### SRC-072 — SeeSchStrO § 58 Schifffahrtspolizeiliche Meldungen

- Authority: Generaldirektion Wasserstraßen und Schifffahrt (ELWIS).
- URL: https://www.elwis.de/DE/Schifffahrtsrecht/Seeschifffahrtsrecht/SeeSchStrO/Achter-Abschnitt/58/58-node.html
- Evidence class: Tier 1.
- Edition or date: Undated web page, accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B13): Reports under SeeSchStrO § 58 are made to the Verkehrszentrale announced under § 60 (i.e. VTS reporting, not a separate scheme).
- Locator: § 58(1).
- Passage: "haben der nach § 60 Absatz 1 bekannt gemachten Verkehrszentrale folgende Angaben zu melden"

### SRC-073 — Bekanntmachung zur Seeschifffahrtsstraßen-Ordnung vom 28. Januar 2014

- Authority: Generaldirektion Wasserstraßen und Schifffahrt, Außenstelle Nord.
- URL: https://www.bundesanzeiger.de/pub/publication/gfKDNVi8i3yMiqFNmCE/content/gfKDNVi8i3yMiqFNmCE/BAnz%20AT%2031.01.2014%20B7.pdf
- Evidence class: Tier 1.
- Edition or date: BAnz AT 31.01.2014 B7 (base text; amended at least 12 times to BAnz AT 09.07.2024 B2; amendments seen do not touch Nr. 29.1).
- Accessed: 29 September 2026.
- Use (B13): SeeSchStrO § 58 reports on the Elbe: Cuxhaven Elbe Traffic sector begins at Tonne Elbe; outbound vessels report at Tonne Elbe to German Bight Traffic on VHF 80. Shows the sector hand-over at the seaward end of the Elbe fairway.
- Locator: Nr. 29.1.2.1 and 29.1.4, pp. 34-35.
- Passage: "Cuxhaven für den Bereich vom Tonne Elbe bis zum Tonnenpaar 53, 54/Reede über UKW-Kanal 71 Küstenfunkstelle Cuxhaven Elbe Traffic"

### SRC-074 — Verkehrszentrale Cuxhaven

- Authority: Wasserstraßen- und Schifffahrtsamt Elbe-Nordsee (WSV).
- URL: https://www.wsa-elbe-nordsee.wsv.de/Webs/WSA/Elbe-Nordsee/DE/2_Schifffahrt/4_Verkehrszentralen/2_Cuxhaven/Cuxhaven_node.html
- Evidence class: Tier 2.
- Edition or date: Undated web page, accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B13): Cuxhaven VTS centre responsible for the Elbe from the Elbe approach to Brunsbüttel and for surveillance around offshore wind farms in the EEZ (lead for German North Sea Traffic).
- Locator: Page body.
- Passage: "Sie ist zuständig für die Sicherheit und Leichtigkeit des Schiffsverkehrs auf der Seeschifffahrtsstraße Elbe im Bereich der Elbeansteuerung bis Brunsbüttel, die Seeraumüberwachung um die Offshore-Windparks in der ausschließlichen Wirtschaftszone"

### SRC-075 — VTS Information (VTS Humber description)

- Authority: Associated British Ports, Humber Estuary Services (Statutory Harbour Authority).
- URL: https://humber.com/estuary_information/marine_information/vessel-traffic-services/vts-description
- Evidence class: Tier 2.
- Edition or date: Undated web page (site copyright 2010-2026), accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B13): VTS Humber area seaward limit (Easington Church 086° to 53°40'N 000°30'E, 180° to 53°30'N 000°30'E, 262° to Donna Nook); compulsory; TOS from seaward limit to Humber Bridge; reporting points at Outer Binks, Outer Sea Reach and Outer Rosse Reach buoys (TSS limbs).
- Locator: VTS area; Reporting points; Types of Service.
- Passage: "Mariners are required to report to VTS, HUMBER on VHF when passing the following reporting points: Outer Binks Light Buoy, Outer Sea Reach Light Buoy or Outer Rosse Reach Light Buoy."

### SRC-076 — Kystverket WFS layer 'VTS tjenesteområde 2021 versjon 2' (layer_696)

- Authority: Norwegian Coastal Administration (Kystverket).
- URL: https://services.kystverket.no/wfs.ashx?service=WFS&version=1.1.0&request=GetFeature&typeName=layer_696&srsName=EPSG:4326
- Evidence class: Tier 2.
- Edition or date: features valid from 2021-04-01 (Kinn 2021-06-01); accessed 29 September 2026.
- Accessed: 29 September 2026.
- Use (B14): Complete set of statutory VTS service areas (six polygons, each referenced to Sjøtrafikkforskriften §6); none overlaps any B-II/19 TSS in this group (Melkøya area max latitude 71.09N, east of 22.56E; others south of 62.05N)
- Locator: Features 1 to 6 (attributes omraadenavn, forskriftsreferanse).
- Passage: "Melkøya tjenesteområde ... Sjøtrafikkforskriften §6"

### SRC-077 — Forskrift om bruk av sjøtrafikksentralenes tjenesteområde og bruk av bestemte farvann (sjøtrafikkforskriften), FOR-2021-02-10-523

- Authority: Lovdata / Ministry of Transport (Norway).
- URL: https://lovdata.no/dokument/SF/forskrift/2021-02-10-523
- Evidence class: Tier 1.
- Edition or date: consolidated text, last amended FOR-2026-06-29-1454 (in force 1 July 2026) as reported by the fetch tool; accessed 29 September 2026.
- Accessed: 29 September 2026.
- Use (B14): §6 lists six VTS service areas (Horten, Brevik, Kvitsøy, Fedje, Kinn, Melkøya); chapter 5 (§§169 to 172) routeing measures in the EEZ with no reporting provision
- Locator: §6; Kapittel 5 §§169 to 172.
- Passage: "Horten tjenesteområde, Brevik tjenesteområde, Kvitsøy tjenesteområde, Fedje tjenesteområde, Kinn tjenesteområde, Melkøya tjenesteområde"

### SRC-078 — Vessel Traffic Service (VTS) centres (contact page)

- Authority: Norwegian Coastal Administration (Kystverket).
- URL: https://www.kystverket.no/en/contact/vts-service/
- Evidence class: Tier 2.
- Edition or date: undated web page; accessed 29 September 2026.
- Accessed: 29 September 2026.
- Use (B14): Lists the six VTS areas (Horten, Brevik, Kvitsøy, Fedje, Kinn, Melkøya) and separately an NOR VTS information service for Barents SRS and TSS
- Locator: Final contact block.
- Passage: "Information service for Barents SRS and routing schemes (TSS) in Norway - NOR VTS"

### SRC-079 — About the Vessel Traffic Service (VTS)

- Authority: Norwegian Coastal Administration (Kystverket).
- URL: https://www.kystverket.no/en/navigation-and-monitoring/vts---vessel-traffic-service/about-the-vessel-traffic-service-vts/
- Evidence class: Tier 2.
- Edition or date: page timestamp 2021-06-02; accessed 29 September 2026.
- Accessed: 29 September 2026.
- Use (B14): Vardø VTS centre (NOR VTS) monitors risk vessels following the offshore routeing measures; its VTS area task is Melkøya
- Locator: Section 'Vardø VTS centre'.
- Passage: "The centre monitors tankers and other risk vessels that follow the routing measures established outside the Norwegian coast."

### SRC-080 — SN.1/Circ.318, New mandatory ship reporting system 'In the Barents Area (Barents SRS)', annex resolution MSC.348(91)

- Authority: IMO (Maritime Safety Committee).
- URL: https://fma.fo/wp-content/uploads/2016/12/2013_navigational_03_sn_circ-318_new-mandatory-ship-reporting-system-in-the-barents-area.pdf
- Evidence class: Tier 1.
- Edition or date: 4 December 2012 (MSC.348(91) adopted 28 November 2012; in force 0000 UTC 1 June 2013); accessed 29 September 2026.
- Accessed: 29 September 2026.
- Use (B14): Barents SRS participation thresholds, geographical boundary (points A to H), reporting to Vardø VTS centre (Norwegian monitoring area)
- Locator: Annex paras 1.1, 2.1 and 3.1.1 (copy hosted by the Faroese Maritime Authority, fma.fo; text is the IMO circular itself).
- Passage: "All Barents SRS reports must be sent to either Vardø VTS centre or Murmansk VTS centre."

### SRC-081 — Barents Ship Reporting System

- Authority: Norwegian Coastal Administration (Kystverket).
- URL: https://www.kystverket.no/en/klima-og-barekraft/barents-srs/
- Evidence class: Tier 2.
- Edition or date: undated web page; accessed 29 September 2026.
- Accessed: 29 September 2026.
- Use (B14): Kystverket states the TSS from Vardø to Røst are inside the Barents SRS operational area; reports in Norwegian area go to NOR VTS (Vardø)
- Locator: Main text.
- Passage: "The traffic separation systems off the Norwegian coast from Vardø to Røst are within the operational area of Barents SRS."

### SRC-082 — Kystverket WFS layer 'TSS områder' (layer_706), services.kystverket.no

- Authority: Norwegian Coastal Administration (Kystverket).
- URL: https://services.kystverket.no/wfs.ashx?service=WFS&version=1.1.0&request=GetFeature&typeName=layer_706&srsName=EPSG:4326
- Evidence class: Tier 2.
- Edition or date: live dataset; accessed 29 September 2026.
- Accessed: 29 September 2026.
- Use (B14): Official polygons of each TSS lane and separation zone; eight clusters named 'Trafikkseparasjonssystemer utenfor norskekysten mellom Vardø og Røst', plus separately named Træna and Halten TSS; used to test inclusion in Barents SRS and VTS areas
- Locator: Features 50 to 79 (attribute tss_navn).
- Passage: "Trafikkseparasjonssystem utenfor Træna"

### SRC-083 — Resolution MSC.190(79), Mandatory ship reporting system in the Western European PSSA (WETREP)

- Authority: IMO (Maritime Safety Committee).
- URL: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC.190(79).pdf
- Evidence class: Tier 1.
- Edition or date: adopted 6 December 2004; accessed 29 September 2026.
- Accessed: 29 September 2026.
- Use (B15): WETREP northern/eastern limit (58°30'N to 62°N at 000°) lies far west of the Træna and Halten TSS (about 005°E to 007°E); WETREP does not include them
- Locator: Annex para 2.1, points 1 to 4.
- Passage: "2 (UK) 58° 30’ N 000° W 3 (UK) 62° N 000° W"

### SRC-084 — Navigation rules (TSS in the Norwegian economic zone)

- Authority: Norwegian Coastal Administration (Kystverket).
- URL: https://www.kystverket.no/en/navigation-and-monitoring/vts---vessel-traffic-service/sailing-rules/
- Evidence class: Tier 2.
- Edition or date: undated web page (refers to changes from 1 June 2021); accessed 29 September 2026.
- Accessed: 29 September 2026.
- Use (B15): Routeing system in the EEZ; applicable ship categories; no reporting obligation stated for the TSS
- Locator: Section 'Navigation rules in the Norwegian economic zone (TSS)'.
- Passage: "Vessels in international traffic that may represent a high environmental risk must follow route measures that take these vessels further off the coast."

### SRC-085 — Maritime Traffic Regulations (unofficial English translation of Forskrift om sjøtrafikk i bestemte farvann og om rutetiltak, FOR-2021-02-10-523)

- Authority: Norwegian Coastal Administration (Kystverket), for the Ministry of Transport.
- URL: https://www.kystverket.no/globalassets/maritime-traffic-regulations---20260601.pdf/download
- Evidence class: Tier 1.
- Edition or date: Translation updated to reflect amendments in force as of 1 July 2026 (file dated 2026-06-01); regulations in force 1 April 2021.
- Accessed: 29 September 2026.
- Use (B16): Complete statutory list of Norwegian VTS areas (s.6: Horten, Brevik, Kvitsøy, Fedje, Kinn, Melkøya); Chapter 5 obligation to use the TSS on the stretches Egersund-Risør and Halten-Utsira; supervision by NCA; no reporting obligation attached to the coastal routeing measures
- Locator: Sections 6, 169-172.
- Passage: "Vessels mentioned in section 170 that operate on the stretches Egersund-Risør, Halten – Utsira and Træna-Vardø use the traffic separation schemes described in the Norwegian Coastal Administration's electronic charts "Kystinfo""

### SRC-086 — Kinn Vessel Traffic Service (VTS) service flyer

- Authority: Norwegian Coastal Administration (Kystverket).
- URL: https://www.kystverket.no/contentassets/3a43d44b50e24a02ba69b50559a4f32c/kinn-vts-service-flyer.pdf
- Evidence class: Tier 2.
- Edition or date: From 1 June 2021.
- Accessed: 29 September 2026.
- Use (B16): Kinn VTS area (nearest VTS area to Off Stad TSS) extends seaward only to the baseline
- Locator: Page 1.
- Passage: "Primarily for inner waters, but extends out to the baseline from Kråkenes in the north, along the baseline south to the southwest of Kinn island."

### SRC-087 — The Irish Coast Guard (policy information page)

- Authority: Department of Transport, Ireland (gov.ie).
- URL: https://www.gov.ie/en/department-of-transport/policy-information/the-irish-coast-guard/
- Evidence class: Tier 2.
- Edition or date: Published 9 July 2019; dateModified 2025-07-08.
- Accessed: 29 September 2026.
- Use (B17): Irish Coast Guard monitors traffic in the Fastnet TSS (monitoring function, not described as a VTS)
- Locator: List of IRCG functions.
- Passage: "Monitors maritime traffic within Ireland's Traffic Separation Schemes (Tuskar/Fastnet)"

### SRC-088 — Resolution A.284(VIII): Routeing systems (original descriptions of Off Smalls, Off Skerries, In the North Channel, Off Tuskar Rock)

- Authority: IMO Assembly.
- URL: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/AssemblyDocuments/A.284(8).pdf
- Evidence class: Tier 1.
- Edition or date: Adopted 20 November 1973 (superseded descriptions; used for approximate location only).
- Accessed: 29 September 2026.
- Use (B18): Approximate positions: Off Smalls separation zone 51 39.1-51 50.7 N; Off Skerries 53 22.8-53 32.1 N 004 31.6-004 52.0 W; In the North Channel 55 15.3-55 24.0 N; Off Tuskar Rock 52 04.7-52 14.0 N 006 00.8-006 11.5 W (Tuskar centreline unchanged in the 1996 amendment, COLREG.2/Circ.41)
- Locator: pp. 30-32.
- Passage: "A separation zone, two miles wide, is centred upon the following geographical positions: (1) 52°14'.0 N., (2) 52°08'.5 N., (3) 52°04'.7 N."

### SRC-089 — General Directions for Navigation in the Port of Liverpool 2012

- Authority: Mersey Docks and Harbour Company (Peel Ports).
- URL: https://www.peelports.com/media/quvgfzuf/general-directions-for-navigation-in-the-port-of-liverpool-2012.pdf
- Evidence class: Tier 2.
- Edition or date: 2012.
- Accessed: 29 September 2026.
- Use (B18): Mersey VTS is the VTS operated by MDHC for the Port of Liverpool (port limits per the Act); reporting points are Q1/Q2, Crosby, Brazil/C22, Woodside/Dukes, Brombro; no reference to the Liverpool Bay TSS
- Locator: Direction 1 definitions (w), (ff); Direction 16.
- Passage: "“Mersey VTS” means the Vessel Traffic Service operated by MDHC - Call Sign “Mersey VTS”"

### SRC-090 — COLREG.2/Circ.60, Annex 3: New traffic separation scheme In Liverpool Bay

- Authority: IMO (compilation of COLREG.2 circulars published by Transportstyrelsen, Sweden).
- URL: https://www.transportstyrelsen.se/globalassets/global/sjofart/dokument/sjotrafik_dok/imo_colreg.2_cirkular.pdf?id=58526
- Evidence class: Tier 1.
- Edition or date: MSC 85 (December 2008).
- Accessed: 29 September 2026.
- Use (B18): Position of the Liverpool Bay TSS (about 53 29.8-53 34.6 N, 003 32-003 41 W), inside the Irish Sea sector excluded from WETREP
- Locator: compilation p. 352.
- Passage: "(a) A separation zone (east of the Douglas Oil Field Platform), 1.0 nautical mile wide"

### SRC-091 — Icelandic Maritime Traffic Service

- Authority: Neyðarlínan ohf (112 Iceland).
- URL: https://www.112.is/en/vaktstod-siglinga
- Evidence class: Tier 2.
- Edition or date: Undated web page, accessed 29 September 2026.
- Accessed: 29 September 2026.
- Use (B19): Current description of the Icelandic Maritime Traffic Service; describes monitoring of ships in 'the reporting system' but does not describe itself as a VTS or name any TSS or VTS area
- Locator: Emergency and safety services section.
- Passage: "The monitoring of ships in the reporting system (manual and automatic)."

### SRC-092 — Resolution MSC.250(83): Adoption of a new mandatory ship reporting system off the south and southwest coast of Iceland (TRANSREP)

- Authority: IMO Maritime Safety Committee.
- URL: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC.250(83).pdf
- Evidence class: Tier 1.
- Edition or date: Adopted 8 October 2007; in force 0000 UTC 1 July 2008.
- Accessed: 29 September 2026.
- Use (B19): TRANSREP (VRS-0010) covers only the eastern ATBA inside Icelandic territorial waters; boundary includes points (8) 64 07.20 N 022 47.50 W and (9) 64 07.20 N 022 41.40 W and (22)/(23) near Reykjanes Point; shore authority Icelandic Maritime Traffic Service (MTS)
- Locator: Annex paras 1-3.4.
- Passage: "The reporting system covers the proposed ATBA (the eastern area) off the south and southwest coast of Iceland located entirely within Icelandic territorial waters"

### SRC-093 — Resolution MSC.316(88): Amendments to the existing mandatory ship reporting system 'Off the south and south-west coast of Iceland' (TRANSREP)

- Authority: IMO Maritime Safety Committee.
- URL: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC.316(88).pdf
- Evidence class: Tier 1.
- Edition or date: Adopted 29 November 2010; in force 1 July 2011.
- Accessed: 29 September 2026.
- Use (B19): TRANSREP participant categories extended; geographical coverage co-ordinates unchanged (only the reference chart replaced)
- Locator: Annex, sections 1-2.
- Passage: "The reference chart, which includes all the area of coverage for the system, is Icelandic chart No.31 (INT 1103) Dyrhólaey – Snæfellsnes (May 2008 edition)"

### SRC-094 — Resolution MSC.63(67), Annex 3: Mandatory ship reporting system in the 'Off Finisterre' traffic separation scheme area (FINREP)

- Authority: IMO Maritime Safety Committee.
- URL: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC.63(67).pdf
- Evidence class: Tier 1.
- Edition or date: Adopted 3 December 1996; in force 0000 UTC 3 June 1997.
- Accessed: 29 September 2026.
- Use (B19): FINREP (VRS-0011) participants; reports to Finisterre Traffic VTS; shore authority Finisterre VTS within CZCS Finisterre
- Locator: Annex 3 paras 1, 3.3, 3.4.
- Passage: "Ships entering the area of coverage shall report to the Finisterre Traffic VTS when crossing the limits mentioned in paragraph 2.1 or when leaving the ports or anchorages in the area."

### SRC-095 — Resolution MSC.162(78): Amendments to the existing mandatory ship reporting system Off Cape Finisterre

- Authority: IMO Maritime Safety Committee.
- URL: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC.162(78).pdf
- Evidence class: Tier 1.
- Edition or date: Adopted 17 May 2004; in force 0000 UTC 1 December 2004.
- Accessed: 29 September 2026.
- Use (B19): FINREP area moved west to meridian 010 15 W and expressly includes the TSS Off Finisterre as amended by A.957(23)
- Locator: Annex, replacement paras 2.1-2.2.
- Passage: "This area includes the traffic separation scheme Off Finisterre and the associated inshore traffic zones adopted by resolution A.767(18), as amended by resolution A.957(23)."

### SRC-096 — Los DST, autopistas del mar

- Authority: Ministerio de Transportes y Movilidad Sostenible (Revista Tramos; text by Salvamento Maritimo).
- URL: https://www.transportes.gob.es/recursos_mfom/comodin/recursos/06_los_dst_autopistas_del_mar.pdf
- Evidence class: Tier 4.
- Edition or date: Tramos, February 2025.
- Accessed: 29 September 2026.
- Use (B19): Current (2025) statement that Salvamento Maritimo controls traffic safety in the Fisterra DST as the VTS function, via the CCS Fisterra, and that mandatory reporting exists at Fisterra
- Locator: pp. 38-43.
- Passage: "En España, Salvamento Marítimo es el encargado de controlar la seguridad del tráfico marítimo en los DST de Fisterra, Tarifa, cabo de Gata y Canarias oriental y occidental"

### SRC-097 — Decreto-Lei n.º 263/2009, de 28 de Setembro (VTS costeiros e portuários)

- Authority: Portugal (Diário da República).
- URL: https://www.marinha.pt/Conteudos_Externos/LexMar2/PGPAT%20100/PGPAT%201000%20-%20Cap%C3%ADtulos/Capitulo%20K%20EST/Dec.%20Lei%20263_2009,%20de%2028Set.pdf
- Evidence class: Tier 1.
- Edition or date: Diário da República, 1.ª série, N.º 188, 28 September 2009 (copy hosted by Marinha).
- Accessed: 29 September 2026.
- Use (B19): Statutory area of the VTS costeiro do continente (same west/south-west limits as COPREP); CCTMC directs the VTS; CCTMC supervises observance of TSS rules; participation thresholds
- Locator: Arts 6, 7, 9, 10(4).
- Passage: "O VTS costeiro do continente presta um serviço de controlo de tráfego marítimo de âmbito nacional, geograficamente delimitado a partir da linha de costa continental"

### SRC-098 — Contact details - Portugal

- Authority: European Maritime Safety Agency (EMSA) DONA directory.
- URL: https://portal.emsa.europa.eu/web/dona/contact-details-portugal
- Evidence class: Tier 4.
- Edition or date: Undated web page, accessed 29 September 2026.
- Accessed: 29 September 2026.
- Use (B19): CCTMC (Paço de Arcos) currently listed under DGRM, operational 24h/7, e-mail oper.vts@dgrm.mm.gov.pt; supports current operation under DGRM (IPTM successor)
- Locator: Portugal entry: Centro de Controlo de Tráfego Maritimo do Continente - CCTMC.
- Passage: "operational 24h/7"

### SRC-099 — Resolution MSC.278(85): Adoption of the new mandatory ship reporting system 'Off the coast of Portugal - COPREP'

- Authority: IMO Maritime Safety Committee.
- URL: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC.278(85).pdf
- Evidence class: Tier 1.
- Edition or date: Adopted 1 December 2008; in force 0000 UTC 1 June 2009.
- Accessed: 29 September 2026.
- Use (B19): COPREP (VRS-0012) participants, area limits (010 14 W north of 38 41 N; line 38 41 N 010 14 W to 36 30 N 009 35 W), reports to Roca Control; Roca Control described as the VTS centre
- Locator: Annex paras 1, 2.1, 3.2, 3.4, 4, 5.
- Passage: "The shore-based authority for COPREP mandatory ship reporting system, to which these reports should be sent, is ROCA CONTROL (identified in paragraph 7)."

### SRC-100 — Resolution MSC.301(87): Amendments to the existing mandatory ship reporting system in the Western European PSSA (WETREP)

- Authority: IMO Maritime Safety Committee.
- URL: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC.301(87).pdf
- Evidence class: Tier 1.
- Edition or date: Adopted 17 May 2010; in force 1 December 2010.
- Accessed: 29 September 2026.
- Use (B19): WETREP amended to add COPREP and 'Coast of Portugal VTS'; Portuguese WETREP contact is ROCA CONTROL; area co-ordinates not amended
- Locator: Annex, items 1-3.
- Passage: "2 In paragraph 6.2.6, under Coastal Vessel Traffic Services (VTS), insert: Coast of Portugal VTS"

### SRC-101 — Resolution MSC.73(69) Mandatory ship reporting systems, Annex 1: Description of the mandatory ship reporting system in the Straits of Malacca and Singapore (STRAITREP)

- Authority: IMO Maritime Safety Committee.
- URL: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC.73(69).pdf
- Evidence class: Tier 1.
- Edition or date: Adopted 19 May 1998; in force 0000 UTC 1 Dec 1998; accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B30): STRAITREP (VRS-0016) operational area, inclusion of the routeing system, participation categories, VTS authority per sector (Klang VTS sectors 1-5, Johor VTS sector 6, Singapore VTS sectors 7-9), Tg Piai - Pulau Karimun Kecil reporting line, Horsburgh Lt as reference point
- Locator: Annex 1 paras 1.1, 2.1, 3.3, 3.4; appendices 1-3.
- Passage: "The operational area of STRAITREP covers the Straits of Malacca and Singapore between longitudes 100 40'E and 104 23'E ... The area includes the routeing system in the Straits of Malacca and Singapore."

### SRC-102 — Port Marine Circular No. 65 of 1998: Mandatory Ship Reporting System in the Straits of Malacca and Singapore - STRAITREP (with SN/Circ.201 and Corr.1)

- Authority: Maritime and Port Authority of Singapore.
- URL: https://www.mpa.gov.sg/api/media/78c165e3-67e4-4da3-9496-c196739374d2/-pc98-65.pdf
- Evidence class: Tier 2.
- Edition or date: 20 Oct 1998 (still cited as current by MPA Singapore Port Information updated 17 Apr 2026); accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B30): Singapore implementation of STRAITREP; sector table (Appendix 3) with VHF channels: Sector 1 Ch 66, 2 Ch 88, 3 Ch 84, 4 Ch 61, 5 Ch 88 (Klang VTS), 6 Ch 88 (Johor VTS); shore facilities of Klang, Johor and Singapore VTS and remote radar stations
- Locator: paras 1-3; SN/Circ.201 Annex 1 para 3.4, para 7; Appendix 3.
- Passage: "(i) Sector 1 to Sector 5 - Klang VTS; (ii) Sector 6 - Johor VTS; and (iii) Sector 7 to Sector 9 - Singapore VTS."

### SRC-103 — VTIS Operational Areas web page (STRAITREP sectors and chartlets)

- Authority: Maritime and Port Authority of Singapore.
- URL: https://www.mpa.gov.sg/port-marine-ops/operations/vessel-traffic-information-system/operational-areas
- Evidence class: Tier 2.
- Edition or date: Page last updated 28 Sep 2026; accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B30): Current sector table: Sectors 1-5 Klang VTS, Sector 6 Johor VTS, Sectors 7 (Ch 73), 8 (Ch 14), 9 (Ch 10) Singapore VTS; chartlets of operational area
- Locator: Sector/VHF channel/VTS authority table.
- Passage: "Sector 7 ... VHF Channel 73 ... SINGAPORE VTS (as rendered by fetch tool; table layout)"

### SRC-104 — Singapore Port Information 2026 (Straits of Malacca and Singapore routeing system, Annexes 1-8; STRAITREP chartlets Appendix 1 and 2)

- Authority: Maritime and Port Authority of Singapore, Hydrographic Division.
- URL: https://file.go.gov.sg/spi2026apr17.pdf
- Evidence class: Tier 3.
- Edition or date: Updated to 17 Apr 2026; accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B30): WGS 84 coordinates of each Malacca/Singapore TSS (from COLREG.2/Circ.44 as amended by COLREG.2/Circ.54); chartlets showing sector boundaries 1-9 (only graphically for sectors 1-6) and Long 103°44.5E, 104°02.1E, 104°22.9E limits
- Locator: pp. 6-14 (Annexes 1-8), p. 16 (STRAITREP), pp. 119-120 (chartlets).
- Passage: "The following are based on IMO document COLREG.2/Cir.44 dated 26 May 1998 and COLREG.2/Cir.54 dated 28 May 2004."

### SRC-105 — Vessel Traffic Information System (VTIS) web page

- Authority: Maritime and Port Authority of Singapore.
- URL: https://www.mpa.gov.sg/port-marine-ops/operations/vessel-traffic-information-system
- Evidence class: Tier 2.
- Edition or date: Page last updated 28 Sep 2026; accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B30): Current operation of STRAITREP and VTIS by MPA; operational area longitudes; sector allocation to Klang, Johor and Singapore VTS; participation thresholds
- Locator: VTIS and STRAITREP sections.
- Passage: "the Straits of Malacca and Singapore between longitudes 100°40'E and 104°23'E"

### SRC-106 — Vessels arriving in Singapore: guide to VHF communication in port and Singapore Strait

- Authority: Maritime and Port Authority of Singapore.
- URL: https://www.mpa.gov.sg/port-marine-ops/arrivals-and-departures/vessels-arriving-in-singapore
- Evidence class: Tier 2.
- Edition or date: Page last updated 28 Sep 2026; accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B30): Longitude limits of STRAITREP Sectors 7, 8 and 9 (VTIS West, Central, East)
- Locator: VHF communication guide table.
- Passage: "Sector 8, STRAITREP operational area (area between Long. 103°44.5'E and 104°02.1'E)"

### SRC-107 — Berlaku 1 Juli 2020, Kemenhub jelaskan sistem pelaporan kapal di TSS Selat Sunda dan Selat Lombok

- Authority: Direktorat Jenderal Perhubungan Laut (Hubla), Kementerian Perhubungan Republik Indonesia.
- URL: https://hubla.dephub.go.id/home/post/read/7657/berlaku-1-juli-2020-kemenhub-jelaskan-sistem-pelaporan-kapal-di-tss-selat-sunda-dan-selat-lombok
- Evidence class: Tier 2.
- Edition or date: 22 Jun 2020; accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B31): SUNDAREP and LOMBOKREP established under KM 129/2020 and KM 130/2020; mandatory for Indonesian-flag ships, foreign ships strongly recommended to participate; Merak VTS (VHF 22/68) for Sunda TSS and Benoa VTS (VHF 16/68) for Lombok TSS; VTS Merak and VTS Benoa to monitor the whole TSS areas; VTS operated by DG Sea Transportation
- Locator: paras 2-3, 6-8.
- Passage: "Sistem Pelaporan dan Informasi Navigasi di Selat Sunda dan Selat Lombok bersifat wajib, yaitu bagi semua kapal berbendera Indonesia yang melintas, menyeberangi/memotong bagan pemisah lalu lintas (TSS)"

### SRC-108 — COLREG.2/Circ.74 New traffic separation schemes and associated measures: In the Sunda Strait; In the Lombok Strait

- Authority: IMO (document hosted by BIMCO).
- URL: https://bimco.org/media/gusfhkrc/colreg2circ74-new-traffic-separation-schemes-secretariat.pdf
- Evidence class: Tier 1.
- Edition or date: 2019 (MSC 101 adoption); implementation 1 Jul 2020; accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B31): Identity and implementation date of the Sunda and Lombok TSS
- Locator: para 1-2 and Annex.
- Passage: "Accordingly, these new traffic separation schemes and associated routeing measures should be implemented on 1 July 2020."

### SRC-109 — Hong Kong Fact Sheet (Marine Department publications)

- Authority: Marine Department, HKSAR Government.
- URL: https://www.mardep.gov.hk/en/materials-and-publications/publications/hk-fact-sheet/index.html
- Evidence class: Tier 2.
- Edition or date: Undated web page; accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B31): VTS covers all navigable waters of Hong Kong; TSS implemented in Tathong Channel
- Locator: Vessel Traffic Services section.
- Passage: "covers all navigable waters of Hong Kong used by sea-going vessels and ferries"

### SRC-110 — Arrangement for Vessel Traffic Service (VTC pamphlet)

- Authority: Marine Department, HKSAR Government.
- URL: https://www.mardep.gov.hk/filemanager/en/share/publications/pdf/materials/vtc_pamphlet.pdf
- Evidence class: Tier 2.
- Edition or date: April 2025; accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B31): Vessels required to participate in Hong Kong Vessel Traffic Service (Cap 313A reg 4: over 300 GT etc.; Cap 548F s57 local vessels); Eastern Approaches sector Ch 12 with calling-in point Tathong Channel Separation Buoy No. 1
- Locator: Participation and VHF sectors panels.
- Passage: "Pursuant to Regulation 4 of the Shipping and port control regulations, (Cap 313A), (a) a vessel of over 300 gross tonnage;"

### SRC-111 — Hong Kong Vessel Traffic Service - VHF Sectors and Calling-in Points (Drawing No. 2025MAR032)

- Authority: Marine Department, HKSAR Government (Hydrographic Office).
- URL: https://www.mardep.gov.hk/filemanager/en/share/pub-services/pdf/vts_vscp.pdf
- Evidence class: Tier 2.
- Edition or date: September 2025; accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B31): Official service name and VHF sector layout: Eastern Approaches Ch 12, Harbour East Ch 02 etc.
- Locator: Chart title and sector labels.
- Passage: "Hong Kong Vessel Traffic Service – VHF Sectors and Calling-in Points"

### SRC-112 — Guide to Hong Kong waters (hkwaterlk_guide)

- Authority: Marine Department, HKSAR Government.
- URL: https://www.mardep.gov.hk/filemanager/en/share/pub-services/pdf/hkwaterlk_guide.pdf
- Evidence class: Tier 4.
- Edition or date: March 2026 Edition; accessed 29 Sep 2026.
- Accessed: 29 September 2026.
- Use (B31): Tathong Channel TSS lies within Hong Kong waters; channel extends from Lei Yue Mun to north of Waglan Island
- Locator: Chapter 2 Principal Fairways and Traffic Separation Schemes.
- Passage: "There are two traffic separation schemes (TSS) within Hong Kong waters which are adopted by IMO: (a) Tathong Channel (b) East Lamma Channel"

### SRC-113 — OP Notice to Shipping N-2-2026: Harbor Operations

- Authority: Panama Canal Authority (ACP), Vice Presidency for Operations.
- URL: https://pancanal.com/wp-content/uploads/2021/08/N02-2026-Harbor-Operations_BMV.pdf
- Evidence class: Tier 2.
- Edition or date: 1 January 2026 (cancels N-2-2025).
- Accessed: 29 September 2026.
- Use (B36): Flamenco Signal Station arrival call at 8 nm from the Pacific Sea Buoy (canal and anchorage arrival coordination); does not name the TSS and does not describe Flamenco as a VTS
- Locator: Harbor Operations, section 2 'Vessel Coordination and Procedures at the Pacific Entrance', para 2a to 2c.
- Passage: "When a vessel reaches a point of eight (8) Nautical Miles from Pacific Sea Buoy (about 11 Nautical Miles from Flamenco Island), it must notify Flamenco Signal Station on Channel 12 (VHF)."

### SRC-114 — COLREG.2/Circ.65 New traffic separation schemes (On the Pacific coast of Panama; At the approaches to Puerto Cristobal)

- Authority: IMO Maritime Safety Committee.
- URL: https://www.panamashipregistry.com/wp-content/uploads/2019/08/COLREG-2-Circ-65.pdf
- Evidence class: Tier 1.
- Edition or date: 23 May 2014; implemented 0000 UTC 1 December 2014.
- Accessed: 29 September 2026.
- Use (B36): Identity and geometry of TSS-0176/0177/0178 (Parts 1 to 3 of B-VIII/1); instrument contains no reporting or VTS provision
- Locator: Para 2; Annex 1 pages 1 to 3.
- Passage: "will be implemented at 0000 hours UTC on 1 December 2014"

### SRC-115 — Ships' Routeing 2025 Edition, Part I mandatory ship reporting systems (data/authoritative/IMO_2025_Mandatory_Reporting_Systems.csv)

- Authority: IMO (project baseline).
- URL: 
- Evidence class: Tier 1.
- Edition or date: 2025 edition.
- Accessed: 29 September 2026.
- Use (B36): Only Part I system in the South American Pacific region is GALREP (VRS-0019, I-I/19), confined to the Galapagos; no Part I system covers Panama or the Peruvian coast
- Locator: Row I-I/19.
- Passage: "In the Galapagos Particularly Sensitive Sea Area [GALREP]"

### SRC-116 — Merchant Marine Circular MMC-304: Implementation of New Ships' Routeing System in Panama

- Authority: Panama Maritime Authority (AMP), Directorate General of Merchant Marine.
- URL: https://www.panamashipregistry.com/wp-content/uploads/2020/08/MMC-304-Nov.-2014.pdf
- Evidence class: Tier 2.
- Edition or date: November 2014.
- Accessed: 29 September 2026.
- Use (B36): Panamanian implementation of Parts 1 to 3; no VTS or reporting requirement announced with the TSS
- Locator: Para 1a and 2.
- Passage: "which covers Part 1 “Gulf of Panama”, Part 2 “Morro de Puercos”, Part 3 “Isla Jicarita” and Part 4 which describes inshore traffic zones"

### SRC-117 — Circular DGPIMA-005-DECCP-2026: Reducción de velocidad por protección de cetáceos en aguas nacionales

- Authority: Panama Maritime Authority (AMP), Dirección General de Puertos e Industrias Marítimas Auxiliares.
- URL: https://www.amp.gob.pa/wp-content/uploads/2026/07/Circular-DGPIMA-005-DECCP-2026-esp-ingl.pdf
- Evidence class: Tier 2.
- Edition or date: 8 July 2026 (supersedes DGPIMA-014-DECCP-2025).
- Accessed: 29 September 2026.
- Use (B36): Current AMP notice on the Gulf of Panama TSS; no VTS or reporting provision
- Locator: Page 1.
- Passage: "esta recomendación es aplicable a ambas vías de circulación del Dispositivo de Separación del Tráfico ubicado en el Golfo de Panamá"

### SRC-118 — Pub. 125 Sailing Directions (Enroute) West Coast of South America

- Authority: US National Geospatial-Intelligence Agency (NGA).
- URL: https://msi.nga.mil/api/publications/download?type=view&key=16694491/SFH00000/Pub125bk.pdf
- Evidence class: Tier 3.
- Edition or date: 17th edition 2025, corrected to 27 August 2026.
- Accessed: 29 September 2026.
- Use (B36): Callao TSS explicitly linked to mandatory reports to TRAMAR (not described as a VTS); Peruvian port entries for Talara, Paita, Salaverry, Chimbote, Pisco/General San Martin and San Nicolas describe the TSS without any VTS; the publication describes VTS Arica, Iquique and Mejillones (Chile) but no Peruvian VTS; Galapagos routeing and Ecuador MRS in Sector 1 only
- Locator: Sector 3: PDF p.57 (Talara, 'Talara Control'), p.58 (Paita), p.67 (Salaverry), p.73 (Chimbote), p.86 (Callao, TRAMAR), p.92 (Pisco/General San Martin), p.94 (San Nicolas); Sector 4 p.106 (VTS Arica).
- Passage: "An IMO-adopted Traffic Separation Scheme (TRAMAR), best seen on the chart, has been established in the approaches to Callao. All vessels must report to TRAMAR on VHF channel 16"

### SRC-119 — Ships' Routeing 2025 Edition, Part I mandatory ship reporting systems (data/authoritative/IMO_2025_Mandatory_Reporting_Systems.csv)

- Authority: IMO (project baseline).
- URL: 
- Evidence class: Tier 1.
- Edition or date: 2025 edition.
- Accessed: 29 September 2026.
- Use (B37): Only Part I system in the South American Pacific region is GALREP (VRS-0019, I-I/19), confined to the Galapagos; no Part I system covers Panama or the Peruvian coast
- Locator: Row I-I/19.
- Passage: "In the Galapagos Particularly Sensitive Sea Area [GALREP]"

### SRC-120 — Vessel Traffic Management System Port of Callao (case study)

- Authority: Wärtsilä (supplier).
- URL: https://www.wartsila.com/insights/case-study/port-of-callao
- Evidence class: Lead only.
- Edition or date: 17 April 2025.
- Accessed: 29 September 2026.
- Use (B37): Peruvian Navy procured and implemented a VTS system at Callao; no service area, TSS coverage or official service description
- Locator: Case study text.
- Passage: "The Marina de Guerra del Perú (Peruvian Navy) needed to find a solution to all these challenges."

### SRC-121 — Rol de la Dirección General de Capitanías y Guardacostas ... y el trabajo realizado en Pisco

- Authority: DICAPI, Marina de Guerra del Perú (presentation hosted on gob.pe).
- URL: https://cdn.www.gob.pe/uploads/document/file/3257676/Presentaci%C3%B3n%20de%20la%20Capitan%C3%ADa%20del%20Puerto%20de%20Pisco.pdf.pdf
- Evidence class: Tier 4.
- Edition or date: May 2022.
- Accessed: 29 September 2026.
- Use (B37): DICAPI lists 'Control y vigilancia del tráfico acuático' among functions; text layer names no VTS for Pisco (command and control slides are images, not read)
- Locator: Slides 4 to 19.
- Passage: "Control y vigilancia del tráfico acuático."

### SRC-122 — 33 CFR 161.55 Vessel Traffic Service Puget Sound and the Cooperative Vessel Traffic Service for the Juan de Fuca Region

- Authority: US Government (eCFR, USCG rule).
- URL: https://www.ecfr.gov/api/versioner/v1/full/2026-09-01/title-33.xml?part=161
- Evidence class: Tier 1.
- Edition or date: eCFR point-in-time 2026-09-01 (section last amended USCG-2016-0498 era); accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B34): Legal VTS Puget Sound area (US navigable waters of the Salish Sea to the US/Canada boundary) and CVTS limits (west ~124°47.5'W to 124°48.6'W, north 49°N, south-east McCurdy Point to Point Partridge)
- Locator: Part 161 subpart C, s.161.55 and 161.55(a).
- Passage: "Canadian and United States Vessel Traffic Centers (Prince Rupert, B.C., Canada; Vancouver, B.C., Canada; and Seattle, WA) manage traffic within the CVTS area irrespective of the International Boundary."

### SRC-123 — 33 CFR Part 167 Offshore Traffic Separation Schemes: ss.167.400-406, 167.450-452, 167.500-503, 167.1310-1315, 167.1320-1323, 167.1330-1332

- Authority: US Government (eCFR, USCG rule).
- URL: https://www.ecfr.gov/api/versioner/v1/full/2026-09-01/title-33.xml?part=167
- Evidence class: Tier 1.
- Edition or date: eCFR point-in-time 2026-09-01 (Pacific sections from 65 FR 53913, 2000 and 75 FR 70826-70830, 19 Nov 2010); accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B34): TSS coordinates used for geometric checks. Note: ss.167.402-404 and 167.451/502 still carry pre-2013 coordinates, superseded internationally by COLREG.2/Circ.64 (see W-S9).
- Locator: ss.167.1312 (southern lanes), 167.1313 (northern lanes), 167.1314 (eastern lanes), 167.1321-1323, 167.1331-1332, 167.401-406, 167.451-452, 167.501-503.
- Passage: "The traffic separation scheme in the Strait of Juan de Fuca consists of five parts: the western lanes, southern lanes, northern lanes, eastern lanes, and precautionary area “PA.”"

### SRC-124 — Vessel Traffic Services Locations

- Authority: USCG Navigation Center (NAVCEN).
- URL: https://www.navcen.uscg.gov/vessel-traffic-services-locations
- Evidence class: Tier 2.
- Edition or date: Undated web page; accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B34): Current operation of VTS Puget Sound (with Prince Rupert and Victoria MCTS in the CVTS), VTS San Francisco (and voluntary OVMRS) and VTS Los Angeles-Long Beach (joint USCG / Marine Exchange, 25 miles from Point Fermin)
- Locator: Sections VTS San Francisco; VTS Los Angeles / Long Beach; VTS Puget Sound.
- Passage: "VTS San Francisco also operates an Offshore Vessel Movement Reporting System (OVMRS). The OVMRS is completely voluntary and operates using a broadcast system with information provided by participants."

### SRC-125 — User's Manual, US Coast Guard Vessel Traffic Service Puget Sound 2024

- Authority: USCG Vessel Traffic Service Puget Sound.
- URL: https://www.navcen.uscg.gov/sites/default/files/pdf/VTS%20User%20Guides/VTS_PS_UsersManual_(2024).pdf
- Evidence class: Tier 2.
- Edition or date: 2024 edition; accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B34): The IMO TSS lies in the VTSPS area; radar coverage of all waters where the TSS exists; CVTS assigns a single service to critical TSS segments independent of the International Boundary (Exchange Line)
- Locator: Introduction pp. iv-v (TSS, Surveillance, CVTS paragraphs).
- Passage: "The Traffic Separation Scheme (TSS) in the VTSPS Area has been adopted by the International Maritime Organization (IMO)."

### SRC-126 — Radio Aids to Marine Navigation 2026, Part 3 (ss.3.5.3.1 Victoria VTS Zone; 3.5.4 CVTS Agreement)

- Authority: Canadian Coast Guard (MCTS).
- URL: https://www.canada.ca/content/dam/ccg-gcc/documents/publications/mcts-sctm/ramn-arnm-2026-eng.pdf
- Evidence class: Tier 3.
- Edition or date: Annual Edition 2026, Version #8, 2026-09-25; copy downloaded from the URL on 2026-09-29 (a re-request later the same day failed with a server reset, so the saved copy was re-read).
- Accessed: 29 September 2026.
- Use (B34): Victoria VTS Zone Sector 1 boundary follows the International Boundary through Juan de Fuca Strait, Haro Strait, Boundary Passage and Strait of Georgia; Sector 1 served by Victoria Traffic Ch 11 and Seattle Traffic Ch 5A; CVTS service areas (s.3.5.4.2 Seattle Traffic; s.3.5.4.3 Victoria Traffic for Haro Strait, Boundary Passage and southern Strait of Georgia); participation mandatory
- Locator: Part 3 pp. 3-15 (Tables 3-1, 3-2), 3-28 to 3-29 (s.3.5.4).
- Passage: "Participation with Prince Rupert, Seattle and Victoria Traffic is mandatory within Canadian and United States territorial waters."

### SRC-127 — data/authoritative/IMO_2025_Mandatory_Reporting_Systems.csv

- Authority: Global VTS project (derived from IMO Ships' Routeing 2025 Part I).
- URL: 
- Evidence class: Tier 1.
- Edition or date: Project baseline; read 2026-09-29.
- Accessed: 29 September 2026.
- Use (B34): Complete list of IMO-adopted mandatory ship reporting systems (VRS-0001 to VRS-0023); none covers the North American Pacific coast or Mexico (VRS-0021 is the US Atlantic right whale system)
- Locator: rows VRS-0001 to VRS-0023.
- Passage: "I-I/21,Off the north-eastern and south-eastern coasts of the United States"

### SRC-128 — Vessel Traffic Services Zones Regulations, SOR/2025-275, Schedule 1 item 1 (Victoria)

- Authority: Government of Canada (Justice Laws).
- URL: https://laws-lois.justice.gc.ca/eng/regulations/SOR-2025-275/FullText.html
- Evidence class: Tier 1.
- Edition or date: Registered 2025-12-12; current to 2026-09-21, last amended 2026-03-31; accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B34): Statutory Victoria VTS Zone limits (southern limit along the International Boundary through Strait of Georgia, Boundary Pass, Haro Strait and Juan de Fuca Strait to 124°40'W); application thresholds s.3(1) and s.9
- Locator: s.3(1), s.7, s.9(1), Schedule 1 item 1.
- Passage: "thence following the international boundary through the Strait of Georgia, Boundary Pass, Haro Strait and Juan de Fuca Strait to 48°28′36″ N, 124°40′00″ W"

### SRC-129 — data/authoritative/IMO_2025_Mandatory_Reporting_Systems.csv

- Authority: Global VTS project (derived from IMO Ships' Routeing 2025 Part I).
- URL: 
- Evidence class: Tier 1.
- Edition or date: Project baseline; read 2026-09-29.
- Accessed: 29 September 2026.
- Use (B35): Complete list of IMO-adopted mandatory ship reporting systems (VRS-0001 to VRS-0023); none covers the North American Pacific coast or Mexico (VRS-0021 is the US Atlantic right whale system)
- Locator: rows VRS-0001 to VRS-0023.
- Passage: "I-I/21,Off the north-eastern and south-eastern coasts of the United States"

### SRC-130 — VTS San Francisco User Manual

- Authority: USCG Vessel Traffic Service San Francisco.
- URL: https://www.navcen.uscg.gov/sites/default/files/pdf/VTS%20User%20Guides/VTS_SF_UserManual_APR2025.pdf
- Evidence class: Tier 2.
- Edition or date: Updated 1 April 2025; accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B35): Offshore Sector = navigable waters within 38 nm of Mount Tamalpais; names the San Francisco Offshore TSS in the traffic routing system of the VTS area; offshore sector reporting to VTS (MSIB 13-04); notes part of the 38 nm arc lies outside navigable waters
- Locator: Part I s.1(a), s.2 (p.6); Part J s.1 (p.7); traffic routing system s.3(c) (p.12).
- Passage: "San Francisco Offshore Traffic Separation Scheme (TSS) is adopted by the International Maritime Organization (IMO). This TSS includes the Northern, Western, and Southern traffic lanes"

### SRC-131 — Vessel Traffic Service Los Angeles-Long Beach (VTS LA-LB) User Manual

- Authority: Marine Exchange of Southern California and USCG (VTS LA-LB).
- URL: https://www.navcen.uscg.gov/sites/default/files/pdf/VTS%20User%20Guides/VTS_LALB_UserManual_210331.pdf
- Evidence class: Tier 2.
- Edition or date: Revised 1 April 2021 (current edition linked from NAVCEN on 2026-09-29).
- Accessed: 29 September 2026.
- Use (B35): VTS LA-LB coverage 25 nm seaward of Point Fermin to berth; San Pedro Traffic jointly operated by USCG and Marine Exchange; only portions of the LA-LB TSS inside VTS area; TSS rules include Santa Barbara TSS amendment; manual lists LA-LB in 33 CFR 161 as a VMRS
- Locator: Introduction p.ii; Appendix A.2-A.4 pp. A-4 to A-6.
- Passage: "Portions of the Traffic Separation Scheme in the Northern and Southern approaches to Los Angeles and Long Beach are within the VTS area."

### SRC-132 — LA/LB Harbor Safety Plan, Chapter I Geographical Boundaries

- Authority: Los Angeles/Long Beach Harbor Safety Committee (published by Marine Exchange of Southern California).
- URL: https://mxsocal.org/assets/pdf/hsp/10-lalb-hsp-chap-i-geographic-boundaries-2018-rev-2026-260318090043.pdf
- Evidence class: Tier 4.
- Edition or date: June 30, 2018, Rev. 2026; accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B35): Confirms partial VTS coverage of the LA-LB TSS; describes a 'Northern Approach' (Santa Barbara Channel) separation zone to about 33°48.9'N 118°46.6'W, which conflicts with the IMO COLREG.2/Circ.64 junction point
- Locator: pp. I-1 to I-3, items A.2 and A.4.
- Passage: "portions of the TSS in the western and southern approaches to the LA/LB Harbors lie within the VTS Area of Responsibility."

### SRC-133 — Auditoría 2024-0006: Administración del Sistema Portuario Nacional Salina Cruz (Cuenta Pública 2024)

- Authority: Auditoría Superior de la Federación (Mexico).
- URL: https://www.asf.gob.mx/Trans/Informes/IR2024b/Documentos/Auditorias/2024_0006_a.pdf
- Evidence class: Lead only.
- Edition or date: Cuenta Pública 2024 audit (review to August 2025); accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B35): Equipment for a Centro de Control de Tráfico Marítimo del Puerto de Salina Cruz procured in 2024 (100% physical progress reported); does not define a VTS area, service status or relation to the TSS
- Locator: Antecedentes section.
- Passage: "El Centro de Control de Tráfico Marítimo del Puerto de Salina Cruz, Oaxaca, se ubica en las coordenadas de georreferenciación: latitud 16.161638 y longitud -95.203713."

### SRC-134 — Modernización y ampliación del Puerto de Salina Cruz

- Authority: Government of Mexico (gob.mx, port modernisation presentation).
- URL: https://www.gob.mx/cms/uploads/attachment/file/883619/SALINA_CRUZ.pdf
- Evidence class: Lead only.
- Edition or date: Undated (2024 milestones); accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B35): Traffic regulation centre construction planned for December 2024
- Locator: p.2.
- Passage: "Construcción de centro regulador de tráfico y reconfiguración de accesos terrestres. Diciembre 2024"

### SRC-135 — The Hong Kong Vessel Traffic Centre

- Authority: Marine Department, HKSAR Government.
- URL: https://www.mardep.gov.hk/en/public-services/port-services/vts/exvts/index.html
- Evidence class: Tier 2.
- Edition or date: undated web page; accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B32): Operational Hong Kong VTS since 1989; third-generation system in operation since 2016
- Locator: page text.
- Passage: ""The Marine Department started to provide the Vessel Traffic Services (VTS) for the port of Hong Kong in 1989.""

### SRC-136 — VTS areas in Australia

- Authority: Australian Maritime Safety Authority (AMSA).
- URL: https://www.amsa.gov.au/safety-navigation/navigating-coastal-waters/vts-areas-australia
- Evidence class: Tier 2.
- Edition or date: last updated 14 November 2023; accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B32): Official list of entities authorised to provide VTS in Australia (Marine Order 64): all port-named VTS areas plus REEFVTS; none on the south-west coast of WA other than Fremantle; Bass Strait providers are Ports Victoria (Melbourne) and TasPorts port VTS areas
- Locator: full list.
- Passage: ""We authorise and audit vessel traffic service (VTS) providers in Australia. Entities authorised to provide vessel traffic services in Australia are:""

### SRC-137 — Modernised Australian Ship Tracking and Reporting System

- Authority: Australian Maritime Safety Authority (AMSA).
- URL: https://www.amsa.gov.au/safety-navigation/navigation-systems/modernised-australian-ship-tracking-and-reporting-system
- Evidence class: Tier 2.
- Edition or date: last updated 23 December 2020; accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B32): MASTREP is a national ship reporting system, mandatory for certain vessels, covering the Australian SRR
- Locator: Participation.
- Passage: ""Vessels that must report to MASTREP are: foreign vessels from the arrival at its first port in Australia until its departure from its final port in Australia all regulated Australian vessels while in the MASTREP area.""

### SRC-138 — Marine order 63 - Vessel reporting systems (current: Marine Order 63 (Vessel reporting systems) 2019, F2019L01463)

- Authority: Australian Maritime Safety Authority (AMSA).
- URL: https://www.amsa.gov.au/about/regulations-and-standards/marine-order-63-vessel-reporting-systems
- Evidence class: Tier 2.
- Edition or date: page last updated 20 August 2026; MO 63 commenced 1 January 2020; accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B32): MASTREP area is the Australian SRR (RCC Australia area in IMO GISIS); MO 63 2019 is current
- Locator: About.
- Passage: ""Modernised Australian ship tracking and reporting system (MASTREP) area. The Rescue Coordination Centre \u2013 Australia is responsible for this area as described in the International Maritime Organization's Global Integrated Shipping Information System""

### SRC-139 — Vessel Traffic Services (VTS areas in Tasmania)

- Authority: TasPorts (Tasmanian Ports Corporation).
- URL: https://www.tasports.com.au/vts
- Evidence class: Tier 2.
- Edition or date: undated web page; accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B32): TasPorts VTS areas are port-named areas (including Grassy, King Island and Lady Barron, Flinders Island); no Bass Strait through-route VTS
- Locator: VTS areas in Tasmania; channel table.
- Passage: ""VTS areas in Tasmania Bell Bay VTS Area Devonport VTS Area Burnie VTS Area Port Latta VTS Area Strahan VTS Area Stanley VTS Area Hobart VTS Area Grassy VTS Area Coles Bay VTS Area Lady Baron VTS Area""

### SRC-140 — Vessel Traffic Services

- Authority: US Coast Guard Navigation Center (NAVCEN).
- URL: https://www.navcen.uscg.gov/vessel-traffic-services
- Evidence class: Tier 2.
- Edition or date: undated web page; accessed 2026-09-29.
- Accessed: 29 September 2026.
- Use (B33): Current operation of USCG Vessel Traffic Centers including Prince William Sound and Puget Sound
- Locator: introductory text.
- Passage: ""The Coast Guard operates 12 Vessel Traffic Centers (VTC): Prince William Sound, Puget Sound, Valdez, Seattle, San Francisco, ...""

### SRC-141 — Radio Aids to Marine Navigation 2026: Part 3: Vessel Traffic Services, section 3.5.4 Co-Operative Vessel Traffic Services (CVTS) Agreement

- Authority: Canadian Coast Guard.
- URL: https://www.canada.ca/en/canadian-coast-guard/corporate/publications/radio-aids-marine-navigation/vessel-traffic-services.html
- Evidence class: Tier 3.
- Edition or date: 2026 edition (web version); accessed 2026-09-29 via WebFetch (PDF and direct HTML download failed).
- Accessed: 29 September 2026.
- Use (B33): CVTS area of operation extends to 125°15'W and 48°00'N and names the traffic separation scheme as the point before which inbound vessels check in with Prince Rupert Traffic; participation mandatory within territorial waters
- Locator: s. 3.5.4.
- Passage: ""The CVTS Area of Operation is defined as 124°40W south along the Washington coast to 48°00N then west to 125°15W and north to 48°35'45"N." "Inbound vessels are to check in with Prince Rupert Traffic on VHF Channel 74 (156.725 MHz) at either 48°00N or 125°15W prior to entering the traffic separation scheme.""

### SRC-142 — Pub. 125 Sailing Directions (Enroute) West Coast of South America, 17th Edition

- Authority: US National Geospatial-Intelligence Agency (NGA).
- URL: https://msi.nga.mil/api/publications/download?key=16694491/SFH00000/Pub125bk.pdf&type=download
- Evidence class: Tier 3.
- Edition or date: 2025, corrected to 19 April 2025; subsequent updates to 27 August 2026.
- Accessed: 29 September 2026.
- Use (B38): VTS Arica, VTS Iquique and VTS Valparaiso descriptions and diagrams showing the TSS inside the VTS boundary limits; VTS Quintero area coordinates; VTS Mejillones area coordinates; Puerto Ilo, Antofagasta, Talcahuano, San Vicente and Concepcion (Boca Grande) sections naming no VTS; CHILREP described as voluntary
- Locator: Sector 3 p.91 (Ilo); Sector 4 p.95 (CHILREP), pp.96-97 (VTS Arica diagram and text), pp.99-102 (VTS Iquique diagram and text), p.113 (VTS Mejillones), p.117 (Antofagasta); Sector 5 pp.147-148 (VTS Quintero), p.149 (VTS Valparaiso diagram), p.152 (VTS Valparaiso text), p.159 (Boca Grande TSS), pp.162-163, 166 (Talcahuano, San Vicente).
- Passage: "A Vessel Traffic Management System (VTM-STM) operates 24 hours in the port limits of Arica and outward to the boundary described in the diagram titled VTS Arica."

### SRC-143 — data/authoritative/IMO_2025_Mandatory_Reporting_Systems.csv

- Authority: Global VTS project (IMO Ships' Routeing 2025 Edition, Part I).
- URL: repository file
- Evidence class: Tier 1.
- Edition or date: Ships' Routeing 2025 Edition baseline.
- Accessed: 29 September 2026.
- Use (B38): The 23 IMO-adopted mandatory ship reporting systems include none for Peru, Chile or Canada (nearest: VRS-0019 GALREP, Ecuador)
- Locator: rows VRS-0001 to VRS-0023.
- Passage: "I-I/19,In the Galapagos Particularly Sensitive Sea Area [GALREP],...,VRS-0019"

### SRC-144 — Sistema de Notificación de la Situación de las Naves (CHILREP), guidance document

- Authority: DIRECTEMAR (Armada de Chile), Servicio de Búsqueda y Salvamento Marítimo - MRCC Chile.
- URL: https://www.directemar.cl/directemar/site/docs/20200515/20200515201601/chilrep_v2_espa__ol.pdf
- Evidence class: Tier 2.
- Edition or date: Actualización agosto 2020.
- Accessed: 29 September 2026.
- Use (B38): CHILREP is voluntary; foreign ships bound for a Chilean port must give 24 h arrival notice; foreign ships in Chilean internal waters must report position at 12:00Z and 24:00Z; Chilean-flag ships must report position daily
- Locator: pp.5-6.
- Passage: "Cuando los buques extranjeros se desplacen por aguas interiores de la República deberán comunicar su posición a las 12:00Z y 24:00Z."

### SRC-145 — data/authoritative/IMO_2025_Mandatory_Reporting_Systems.csv

- Authority: Global VTS project (IMO Ships' Routeing 2025 Edition, Part I).
- URL: repository file
- Evidence class: Tier 1.
- Edition or date: Ships' Routeing 2025 Edition baseline.
- Accessed: 29 September 2026.
- Use (B39): The 23 IMO-adopted mandatory ship reporting systems include none for Peru, Chile or Canada (nearest: VRS-0019 GALREP, Ecuador)
- Locator: rows VRS-0001 to VRS-0023.
- Passage: "I-I/19,In the Galapagos Particularly Sensitive Sea Area [GALREP],...,VRS-0019"

### SRC-146 — Pub. 124 Sailing Directions (Enroute) East Coast of South America, 16th Edition

- Authority: US National Geospatial-Intelligence Agency (NGA).
- URL: https://msi.nga.mil/api/publications/download?key=16694491/SFH00000/Pub124bk.pdf&type=download
- Evidence class: Tier 3.
- Edition or date: 2025, corrected to 13 February 2025; subsequent updates to 12 March 2026.
- Accessed: 29 September 2026.
- Use (B39): Estrecho de Magallanes reporting obligations (entry/exit reports to the Maritime Authority in Punta Arenas; 4-hourly or 0800/2000 CHILREP position reports during passage); Punta Arenas port section observes the TSS and names no VTS
- Locator: Sector 8 pp.247-248 (Estrecho de Magallanes Regulations); p.258 (Punta Arenas contact information, Directions).
- Passage: "During the passage, vessels must report their position and speed every 4 hours if not carrying a pilot, or at 0800 and 2000 if carrying a pilot. This position report (CHILREP) is sent to the Maritime Authority"

### SRC-147 — Pub. 145 Sailing Directions (Enroute) Nova Scotia and the St. Lawrence, 19th Edition

- Authority: US National Geospatial-Intelligence Agency (NGA).
- URL: https://msi.nga.mil/api/publications/download?key=16694491/SFH00000/Pub145bk.pdf&type=download
- Evidence class: Tier 3.
- Edition or date: 2025, corrected to 9 August 2025; subsequent updates to 25 June 2026.
- Accessed: 29 September 2026.
- Use (B39): TSS established for entering and leaving Chedabucto Bay; Strait of Canso and Eastern Approaches VTS Zone limits; mandatory participation; call sign Canso Traffic, VHF 14, 24 h operation; Canso Traffic (VCO) contact incl. MCTS Sydney e-mail
- Locator: Sector 4, para 4.1 Regulations and Vessel Traffic Service (print p.103); Canso Contact Information table (para 4.20).
- Passage: "The station identifier of the Canso VTS Center is “Canso Traffic” and can be contacted on VHF channel 14."

### SRC-148 — Pub. 147 Sailing Directions (Enroute) Caribbean Sea Volume I

- Authority: US National Geospatial-Intelligence Agency (NGA).
- URL: https://msi.nga.mil/api/publications/download?key=16694491/SFH00000/Pub147bk.pdf&type=view
- Evidence class: Tier 3.
- Edition or date: 18th Edition 2025, file updated 28 August 2026.
- Accessed: 29 September 2026.
- Use (B42): Each Cuban TSS is noted with its inshore traffic zone; Cuban TSS are observed from control posts and vessels, which do not call for information except for infringements. No VTS or ship reporting system is described for any of the seven schemes.
- Locator: Sector 4 paras 4.1 (p.42), 4.3 (p.44), 4.5 (p.45), 4.18 (p.53), 4.25 (p.56, Old Bahama Channel and Bahia de Nuevitas), 4.37 (p.60); Sector 5 paras 5.1 (p.66) and 5.2 (p.67).
- Passage: "Such control posts or vessels shall not call for any information, except in cases involving infringements by shipping within the Traffic Separation Scheme, or other types of infringements of national law."

### SRC-149 — Pub. 140 Sailing Directions (Planning Guide) North Atlantic Ocean and Adjacent Seas, Cuba chapter

- Authority: US National Geospatial-Intelligence Agency (NGA).
- URL: https://msi.nga.mil/api/publications/download?key=16694492/SFH00000/Pub140bk.pdf&type=view
- Evidence class: Tier 3.
- Edition or date: 18th Edition 2025, file updated 20 June 2026.
- Accessed: 29 September 2026.
- Use (B42): Cuba country chapter has sections on Pilotage, Pollution, Regulations, Prohibited Areas and Search and Rescue but no Vessel Traffic Service or Ship Reporting System section (other country chapters in the same volume carry such sections). Port approach reporting is to the Port Signal Station on VHF 16.
- Locator: Cuba chapter pp.183 to 185 (Regulations; Search and Rescue).
- Passage: "All vessels approaching Cuban ports should contact the Port Signal Station on VHF channel 16, or by light signals, to announce their presence, nationality, and characteristics."

### SRC-150 — OP Notice to Shipping N-3-2026 Communication on Transit Activities

- Authority: Panama Canal Authority (ACP), Vice Presidency for Operations.
- URL: https://pancanal.com/wp-content/uploads/2021/08/N03-2026-Communication_BMV.pdf
- Evidence class: Tier 2.
- Edition or date: 1 January 2026.
- Accessed: 29 September 2026.
- Use (B43): ACP runs an Enhanced Vessel Traffic Management System (EVTMS) fed by VUMPA pre-arrival data: an information and scheduling system, with no service area or TSS coverage stated.
- Locator: Section 3, p.3.
- Passage: "this information is incorporated into the production database of the Enhanced Vessel Traffic Management System (EVTMS) and other operational systems."

### SRC-151 — Pub. 148 Sailing Directions (Enroute) Caribbean Sea Volume II

- Authority: US National Geospatial-Intelligence Agency (NGA).
- URL: https://msi.nga.mil/api/publications/download?key=16694491/SFH00000/Pub148bk.pdf&type=view
- Evidence class: Tier 3.
- Edition or date: 19th Edition 2025, file updated 4 September 2026.
- Accessed: 29 September 2026.
- Use (B43): Notes the IMO TSS in the approaches to Puerto Cristobal; states the Panama Canal VTMS 'covers the approaches to Colon and its terminals' with no boundary, and gives the Cristobal Signal Station call point as 6 or 12 miles from the breakwaters, which conflicts with ACP N-2-2026 (8 NM).
- Locator: Sector 4 paras 4.38 (p.120), 4.40 (p.123), 4.44 (pp.127 to 129).
- Passage: "The Panama Canal Vessel Traffic Management System (VTMS) covers the approaches to Colon and its terminals."

### SRC-152 — Order No. 1226-r: Traffic separation schemes in the territorial sea of the Russian Federation

- Authority: Government of the Russian Federation (text on third-party host meganorm.ru).
- URL: https://meganorm.ru/Data2/1/4293849/4293849842.htm
- Evidence class: Lead only.
- Edition or date: 2 September 2006.
- Accessed: 29 September 2026.
- Use (B43): National scheme No. 12 Proliv Bussol' and No. 13 Fourth Kuril Strait, with geometry matching the IMO schemes; the text sets lanes and directions only, with no VTS or reporting provision. Third-party reproduction of an official instrument; not verified on pravo.gov.ru.
- Locator: Section 8 (scheme No. 12) and section 9 (scheme No. 13).
- Passage: "Схема разделения движения № 13. Четвертый Курильский пролив (Курильские острова). Схема разделения движения включает две полосы движения, разделенные зоной"

### SRC-153 — Pub. 155 Sailing Directions (Enroute) East Coast of Russia

- Authority: US National Geospatial-Intelligence Agency (NGA).
- URL: https://msi.nga.mil/api/publications/download?key=16694491/SFH00000/Pub155bk.pdf&type=view
- Evidence class: Tier 3.
- Edition or date: 16th Edition 2026, file updated 4 September 2026.
- Accessed: 29 September 2026.
- Use (B43): Notes the IMO TSS in Chetvertyy Kuril'skiy Proliv and in Proliv Bussol' with no VTS or reporting text (VTS are described elsewhere in the volume for Petropavlovsk-Kamchatskiy, Magadan, Zaliv Aniva, Vanino, Zaliv Petra Velikogo). Severo-Kuril'skiy (on Vtoroy Kuril'skiy Proliv, not the Fourth Strait) has only Port Control and pilots.
- Locator: Sector 4 paras 4.1 (p.56), 4.6 (pp.58 to 59), 4.15 (p.61), 4.29 (p.65).
- Passage: "An IMO-approved Traffic Separation Scheme lies in the waters of Chetvertyy Kuril'sky Proliv and may best be seen on the appropriate chart."

### SRC-154 — Pub. 120 Sailing Directions (Planning Guide) Pacific Ocean and Southeast Asia, Russia chapter

- Authority: US National Geospatial-Intelligence Agency (NGA).
- URL: https://msi.nga.mil/api/publications/download?key=16694492/SFH00000/Pub120bk.pdf&type=view
- Evidence class: Tier 3.
- Edition or date: 15th Edition 2025, file updated 28 August 2026.
- Accessed: 29 September 2026.
- Use (B43): Lists Russian east coast TSS (including Proliv Bussol and Chetvertyy Kurilskiy Proliv as IMO approved) and lists 19 Russian VTS (Pacific: Zaliv Petra Velikogo, Nakhodka, Vladivostok, Zaliv Aniva, Vanino, Petropavlovsk-Kamchatskiy, Magadan) plus VTMS at Nevelsk and Okhotsk. None is in the Kuril Islands. Foreign secondary list, not an official Russian list.
- Locator: Russia chapter pp.497 to 498 (Traffic Separation Schemes; Vessel Traffic Service).
- Passage: "Vessel Traffic Management Systems are in operation in Nevelsk (46˝40'N., 141°51'E.) and Okhotsk (59°21'N., 143°11'E.)."

### SRC-155 — Обязательные постановления в морском порту Корсаков (draft, file pr_mt_korsakov_op.doc)

- Authority: Ministry of Transport of the Russian Federation (draft document on mintrans.gov.ru).
- URL: https://mintrans.gov.ru/file/398609
- Evidence class: Lead only.
- Edition or date: Undated draft; file metadata March 2013; approval status and currency not established.
- Accessed: 29 September 2026.
- Use (B44): Korsakov port VTS (СУДС) zone limited by the coast and points 46°37.50'N 142°26.00'E, 46°25.00'N 142°30.00'E, 46°25.00'N 143°04.00'E, 46°35.70'N 143°04.00'E (Aniva Bay only); scheme off Cape Aniva lies south and east of this zone
- Locator: Section on VTS zone (Зона действия СУДС).
- Passage: "Зона действия СУДС ограничена береговой линией и прямой линией, соединяющей по порядку точки с координатами:1) 46°37,50' северной широты и 142°26,00' восточной долготы"

### SRC-156 — data/authoritative/IMO_2025_Mandatory_Reporting_Systems.csv

- Authority: Global VTS project (derived from IMO Ships' Routeing 2025 Part I).
- URL: repo:data/authoritative/IMO_2025_Mandatory_Reporting_Systems.csv
- Evidence class: Tier 1.
- Edition or date: Ships' Routeing 2025 Edition baseline.
- Accessed: 29 September 2026.
- Use (B44): VRS-0022 = I-I/22 Off Chengshan Jiao Promontory; VRS-0023 = I-I/23 The Canary Islands [CANREP]; no Part I system for the Russian Pacific (Sakhalin, Primorye) areas
- Locator: Rows I-I/22, I-I/23.
- Passage: "I-I/23,The Canary Islands [CANREP],847,Mandatory ship reporting systems,Part I,VRS-0023"

### SRC-157 — Обязательные постановления в морском порту Находка (Order of Mintrans of Russia No. 169 of 23 June 2011, reg. No. 21263)

- Authority: Ministry of Transport of the Russian Federation (published in Rossiyskaya Gazeta).
- URL: https://rg.ru/documents/2011/07/05/naxodka-site-dok.html
- Evidence class: Tier 1.
- Edition or date: 23 June 2011 original text; RG publication July 2011.
- Accessed: 29 September 2026.
- Use (B44): Regional VTS of Peter the Great Gulf (РСУДС) sector No. 2 (inside Nakhodka Gulf, VTS acts as port VTS 'Nakhodka-Traffic') and sector No. 1B on the approaches to Nakhodka Gulf (south to the territorial sea boundary, 132°28.00'E to 133°43.00'E, VHF 9)
- Locator: Paras 52-55.
- Passage: "На подходах к заливу Находка в секторе № 1 Б, который ограничен с юга границей территориального моря, с запада меридианом 132°28,00' восточной долготы, с востока меридианом 133°43,00' восточной долготы, связь с РСУДС осуществляется на канале 9 ОВЧ."

### SRC-158 — Приказ Минтранса России от 23.06.2011 N 169 (ред. от 15.12.2017)

- Authority: legalacts.ru (third-party consolidation of Mintrans Order No. 169).
- URL: https://legalacts.ru/doc/prikaz-mintransa-rf-ot-23062011-n-169/
- Evidence class: Lead only.
- Edition or date: Consolidated to amendment of 15 December 2017.
- Accessed: 29 September 2026.
- Use (B44): Paras 52-54 on РСУДС sectors unchanged as at the 15.12.2017 amendment; does not establish that the order is in force in 2026
- Locator: Header '(ред. от 15.12.2017)'; paras 52-54.
- Passage: "Приказ Минтранса России от 23.06.2011 N 169 (ред. от 15.12.2017)"

### SRC-159 — Resolution MSC.389(94): Amendments to the existing mandatory ship reporting system "Off Chengshan Jiao Promontory"

- Authority: IMO Maritime Safety Committee.
- URL: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC%20389%2094.pdf
- Evidence class: Tier 1.
- Edition or date: Adopted 21 November 2014; in force 0000 UTC 1 June 2015.
- Accessed: 29 September 2026.
- Use (B44): VRS-0022 area (24 nm radius around Chengshan Jiao VTS Centre, 37°23'.65N 122°42'.12E), participating ships, competent authority (Weihai MSA), VTS Centre as shore authority with radar and continuous watch, compulsory reports to VTS by ships NUC or at anchor in the TSSs
- Locator: Annex 16, paras 1.1, 2.1, 3.3, 4.1-4.2, 7.1-7.2.
- Passage: "The waters covered by the Ship Reporting System is the water area with the VTS Centre (geographical position is 37°23′.65N, 122°42′.12E) as the centre and 24 miles as the radius."

### SRC-160 — COLREG.2/Circ.66 Amended traffic separation schemes, Annex 2: "In the waters off the Chengshan Jiao Promontory"

- Authority: IMO (COLREG.2/Circ.66; copy hosted by Vietnam Maritime Administration).
- URL: https://www.vimawa.gov.vn/f/Circ%2066.pdf
- Evidence class: Tier 1.
- Edition or date: 21 November 2014; implemented 0000 UTC 1 June 2015.
- Accessed: 29 September 2026.
- Use (B44): Coordinates of inner TSS (points 1-10, 13-15, 26-27) and outer North (11-12, 14-17), East (18-23) and South (20, 24-28) TSSs; cross-reference to the mandatory SRS
- Locator: Annex 2, Parts I and II, paras (a)-(v); Note under title.
- Passage: "Note: See mandatory ship reporting system "Off the Chengshan Jiao Promontory"."

### SRC-161 — Notice on the revised Chengshan Jiao VTS rules and VTS User Guide (in force 2 December 2024)

- Authority: Shandong Maritime Safety Administration (China MSA).
- URL: https://www.sd.msa.gov.cn/art/2024/11/12/art_1443_1818894.html
- Evidence class: Tier 2.
- Edition or date: 12 November 2024.
- Accessed: 29 September 2026.
- Use (B44): Chengshan Jiao VTS area includes the routeing lanes and precautionary areas (added at Pass 4 by the independent checker)
- Locator: Notice text on fishing within the VTS area.
- Passage: "VTS区域内的警戒区及通航分道"

### SRC-162 — Resolution MSC.213(81): Mandatory ship reporting system for the Canary Islands (CANREP)

- Authority: IMO Maritime Safety Committee.
- URL: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC.213(81).pdf
- Evidence class: Tier 1.
- Edition or date: Adopted 12 May 2006; in force 0000 UTC 1 December 2006.
- Accessed: 29 September 2026.
- Use (B45): VRS-0023 reporting area polygon (points A-N), participating ships (tankers 600 dwt and above carrying heavy grades), MRCC Las Palmas / MRCC Tenerife as report recipients split at 015°30'W
- Locator: Annex 1, paras 1.1, 2.1, 3.4.1; Appendix 1.
- Passage: "The proposed maritime area is bounded by a polygonal line connecting points along the outer limit of the territorial sea (12 nautical miles) that surrounds the archipelago"

### SRC-163 — COLREG.2/Circ.57 New and amended existing traffic separation schemes, Annex 1: New traffic separation schemes for the Canary Islands

- Authority: IMO (COLREG.2/Circ.57; copy hosted by Shanghai Maritime University CIMRC).
- URL: https://cimrc.shmtu.edu.cn/_upload/article/files/63/dc/35c66be74d12873254dc88a2ef00/8c6a3c5f-5a85-4450-980a-5534de9fcd0a.pdf
- Evidence class: Tier 1.
- Edition or date: 26 May 2006; implemented 0000 UTC 1 December 2006.
- Accessed: 29 September 2026.
- Use (B45): Coordinates of the Eastern TSS (between Grand Canary and Fuerteventura) and Western TSS (between Grand Canary and Tenerife); voluntary notification via Las Palmas MRCC / Tenerife MRCC on VHF 16
- Locator: Annex 1, sections 2 and 3, Notes.
- Passage: "Note: Ships that so wish may give voluntary notification of entry to and departure from the TSS via the Las Palmas Regional MRCC, using VHF channel 16."

### SRC-164 — Visita el Centro de Coordinación de Salvamento Marítimo en Las Palmas de Gran Canaria

- Authority: Government of Spain (La Moncloa press office, Ministry of Transport).
- URL: https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/transportes/Paginas/2020/201120-salvamento.aspx
- Evidence class: Tier 4.
- Edition or date: 20 November 2020.
- Accessed: 29 September 2026.
- Use (B45): CCS Las Palmas (Salvamento Marítimo) coordinates maritime safety and SAR and monitors traffic in the eastern Canary Islands; no VTS designation or TSS-specific VTS area stated
- Locator: Press release body.
- Passage: "Desde el CCS Las Palmas se coordinan las actuaciones para proteger la seguridad marítima y la vida humana en la mar en la parte oriental del archipiélago canario."

### SRC-165 — Salvamento Marítimo auxilió en 2023 a 43.994 personas en Canarias, 20.997 migrantes

- Authority: RTVC / EFE (media).
- URL: https://rtvc.es/salvamento-maritimo-auxilio-en-2023-a-43-994-personas-en-canarias-20-997-migrantes/
- Evidence class: Lead only.
- Edition or date: 2 February 2024.
- Accessed: 29 September 2026.
- Use (B45): Media report of Salvamento Marítimo statistics: CCS Las Palmas and CCS Tenerife 'controlled' ships transiting the eastern and western Canary TSS (lead for a traffic-monitoring function; not a VTS designation)
- Locator: Article body.
- Passage: "El Centro de Coordinación de Salvamento ubicado en Las Palmas controló 2.023 buques a su paso por el Dispositivo de Separación de Tráfico de Canarias oriental"

### SRC-166 — Radio Aids to Marine Navigation 2026, Part 2 (facilities information): 2.1.1 Halifax, Nova Scotia

- Authority: Canadian Coast Guard.
- URL: https://www.canada.ca/en/canadian-coast-guard/corporate/publications/radio-aids-marine-navigation/facilities-information.html
- Evidence class: Tier 3.
- Edition or date: 2026 edition (accessed 2026-09-29).
- Accessed: 29 September 2026.
- Use (B40): Fundy Traffic is provided from Halifax MCTS Centre.
- Locator: 2.1.1 Halifax.
- Passage: "For Vessel Traffic Services, call Halifax Traffic ( Part 3.7.3.4 of this publication) or Fundy Traffic ( Part 3.7.3.7 of this publication)."

### SRC-167 — US Coast Pilot 1, Chapter 9

- Authority: NOAA Office of Coast Survey.
- URL: https://nauticalcharts.noaa.gov/publications/coast-pilot/files/cp1/CPB1_C09_WEB.pdf
- Evidence class: Tier 3.
- Edition or date: Current edition (27 Sep 2026).
- Accessed: 29 September 2026.
- Use (B40): Approach described with no VTS (Coast Pilot) / complete list of operating US VTS incl. Tampa (NAVCEN); added at Pass 4 by the independent checker
- Locator: Chapter text on the approach.

### SRC-168 — 33 CFR Part 169 Subpart B Establishment of two mandatory ship reporting systems for the protection of northern right whales

- Authority: US Coast Guard / eCFR.
- URL: https://www.ecfr.gov/api/versioner/v1/full/2026-09-01/title-33.xml?part=169
- Evidence class: Tier 1.
- Edition or date: eCFR point-in-time 2026-09-01 (accessed 2026-09-29).
- Accessed: 29 September 2026.
- Use (B40): WHALESNORTH and WHALESSOUTH areas, season, participants (self-propelled ships of 300 GT or more), shore-based authority (USCG); these are the only mandatory ship reporting systems in 33 CFR 169 Subpart B.
- Locator: 169.100, 169.102, 169.105, 169.110, 169.115, 169.125, 169.130.
- Passage: "then south to 41°00' N, 68°31' W; then west to 41°00' N, 69°17' W; then northeast to 42°05' N, 70°02' W"

### SRC-169 — US Coast Pilot 2, Chapter 7

- Authority: NOAA Office of Coast Survey.
- URL: https://nauticalcharts.noaa.gov/publications/coast-pilot/files/cp2/CPB2_C07_WEB.pdf
- Evidence class: Tier 3.
- Edition or date: Current edition (27 Sep 2026).
- Accessed: 29 September 2026.
- Use (B40): Approach described with no VTS (Coast Pilot) / complete list of operating US VTS incl. Tampa (NAVCEN); added at Pass 4 by the independent checker
- Locator: Chapter text on the approach.

### SRC-170 — 33 CFR 165.100 (RNA, USCG Northeast District) and 165.501 (Chesapeake Bay entrance and Hampton Roads RNA)

- Authority: US Coast Guard / eCFR.
- URL: https://www.ecfr.gov/api/versioner/v1/full/2026-09-01/title-33.xml?part=165&section=165.501
- Evidence class: Tier 1.
- Edition or date: eCFR point-in-time 2026-09-01 (accessed 2026-09-29).
- Accessed: 29 September 2026.
- Use (B40): Regulated navigation areas contain situational notification duties (impairments, emergencies, movements under RNA conditions) and repeat VMRS Buzzards Bay rules; they do not establish a named ship reporting scheme for the TSS.
- Locator: 165.100(d); 165.501.
- Passage: "A vessel over 100 gross tons, which is underway in the Regulated Navigation Area, that has its ability to maneuver become impaired for any reason, shall, as soon as possible, report the impairment to the Captain of the Port."

### SRC-171 — Vessel Traffic Service New York User's Manual

- Authority: USCG Sector New York, VTS New York.
- URL: https://www.navcen.uscg.gov/sites/default/files/pdf/VTS%20User%20Guides/VTS_NY_UserManuaFeb2023.pdf
- Evidence class: Tier 2.
- Edition or date: Revised January 2023 (current link on NAVCEN, accessed 2026-09-29).
- Accessed: 29 September 2026.
- Use (B40): VTS New York area boundary (Breezy Point to entrance buoys of Ambrose, Swash and Sandy Hook Channels to Sandy Hook); towing vessels may call VTS on entering the offshore Precautionary Zone (guidance, not an area extension).
- Locator: Area chartlet legend (p.19); Guidelines for Ambrose Channel Tug and Barge Operations.
- Passage: "These calls may be made upon entering the offshore "Precautionary Zone" or anytime thereafter."

### SRC-172 — Local Notice to Mariners, District 1, 06/10/2025 (Ambrose Channel proposed ATON changes)

- Authority: USCG First District / NAVCEN.
- URL: https://navcen.uscg.gov/sites/default/files/pdf/lnms/lnm01242025.pdf
- Evidence class: Tier 3.
- Edition or date: LNM dated 2025-06-10; proposal window 2025-04-03 to 2026-10-03.
- Accessed: 29 September 2026.
- Use (B40): Positions of Ambrose Channel Lighted Buoy 1 (40.46876 N, 73.87223 W), Lighted Bell Buoy 2 (40.47293 N, 73.86755 W) and Lighted Whistle Buoy A (40.45778 N, 73.83673 W); all proposed for discontinuance.
- Locator: Ambrose Channel / ATON Proposed Notice of Change, LLNR 34785, 34796, 34797.
- Passage: "Location: 40.46876° N / 73.87223° W Aid Name: Ambrose Channel Lighted"

### SRC-173 — US Coast Pilot 3, Chapter 6

- Authority: NOAA Office of Coast Survey.
- URL: https://nauticalcharts.noaa.gov/publications/coast-pilot/files/cp3/CPB3_C06_WEB.pdf
- Evidence class: Tier 3.
- Edition or date: Current edition (27 Sep 2026).
- Accessed: 29 September 2026.
- Use (B41): Approach described with no VTS (Coast Pilot) / complete list of operating US VTS incl. Tampa (NAVCEN); added at Pass 4 by the independent checker
- Locator: Chapter text on the approach.

### SRC-174 — Maritime Exchange for the Delaware River and Bay vessel reporting (search snippet)

- Authority: Search result only (philadelphiaencyclopedia.org summary; not opened).
- URL: https://philadelphiaencyclopedia.org/essays/philadelphia-maritime-exchange/
- Evidence class: Lead only.
- Edition or date: n/a.
- Accessed: 29 September 2026.
- Use (B41): Lead: the Maritime Exchange (a trade association) historically ran ship reporting stations including Cape Henlopen; vessels are "requested" to pass position/ETA information. Not an official source; not a VTS.
- Locator: Search snippet.

### SRC-175 — US Coast Pilot 3, Chapter 9

- Authority: NOAA Office of Coast Survey.
- URL: https://nauticalcharts.noaa.gov/publications/coast-pilot/files/cp3/CPB3_C09_WEB.pdf
- Evidence class: Tier 3.
- Edition or date: Current edition (27 Sep 2026).
- Accessed: 29 September 2026.
- Use (B41): Approach described with no VTS (Coast Pilot) / complete list of operating US VTS incl. Tampa (NAVCEN); added at Pass 4 by the independent checker
- Locator: Chapter text on the approach.

### SRC-176 — US Coast Pilot 4, Chapter 6

- Authority: NOAA Office of Coast Survey.
- URL: https://nauticalcharts.noaa.gov/publications/coast-pilot/files/cp4/CPB4_C06_WEB.pdf
- Evidence class: Tier 3.
- Edition or date: Current edition (27 Sep 2026).
- Accessed: 29 September 2026.
- Use (B41): Approach described with no VTS (Coast Pilot) / complete list of operating US VTS incl. Tampa (NAVCEN); added at Pass 4 by the independent checker
- Locator: Chapter text on the approach.

### SRC-177 — US Coast Pilot 4, Chapter 5

- Authority: NOAA Office of Coast Survey.
- URL: https://nauticalcharts.noaa.gov/publications/coast-pilot/files/cp4/CPB4_C05_WEB.pdf
- Evidence class: Tier 3.
- Edition or date: Current edition (27 Sep 2026).
- Accessed: 29 September 2026.
- Use (B41): Approach described with no VTS (Coast Pilot) / complete list of operating US VTS incl. Tampa (NAVCEN); added at Pass 4 by the independent checker
- Locator: Chapter text on the approach.

### SRC-178 — VTS Houston-Galveston User's Manual 2025

- Authority: USCG Sector Houston-Galveston, VTS Houston-Galveston.
- URL: https://www.navcen.uscg.gov/sites/default/files/pdf/VTS%20User%20Guides/VTS_HG_UserManual_2025.pdf
- Evidence class: Tier 2.
- Edition or date: Revised March 2025 (accessed 2026-09-29).
- Accessed: 29 September 2026.
- Use (B41): Current operation and participation categories (VMRS users, VTS users) of VTS Houston-Galveston.
- Locator: User groups page.
- Passage: "VMRS – Vessel Movement Reporting System. The mandatory system operated by the VTS used to monitor and track vessel movements."

### SRC-179 — Centro de Control de Tráfico Marítimo

- Authority: Administración del Sistema Portuario Nacional Veracruz (ASIPONA Veracruz).
- URL: https://www.puertodeveracruz.com.mx/infraestructura/centro-de-control-de-trafico-maritimo/
- Evidence class: Tier 2.
- Edition or date: Undated web page, site (c) 2026 (accessed 2026-09-29).
- Accessed: 29 September 2026.
- Use (B41): Existence, functions, equipment (X and S band radar, AIS) and contact (VHF 10 and 16) of the Veracruz maritime traffic control centre, operating as auxiliary to the Capitanía de Puerto.
- Locator: Main page text.
- Passage: "instaló el Centro de Control de Tráfico Marítimo de Veracruz quien se encarga de vigilar, controlar, prestar asistencia a la navegación"

### SRC-180 — Centro de Control de Tráfico Marítimo: Área de Influencia

- Authority: ASIPONA Veracruz.
- URL: https://www.puertodeveracruz.com.mx/infraestructura/centro-de-control-de-trafico-maritimo/area-de-influencia/
- Evidence class: Tier 2.
- Edition or date: Undated web page (accessed 2026-09-29).
- Accessed: 29 September 2026.
- Use (B41): The CCTMVER control area expressly includes the traffic separation zones, lanes and precautionary areas; bounding box coordinates.
- Locator: Área de Influencia text.
- Passage: "El área de control de tráfico marítimo ejercido por el CCTMVER, incluye las zonas de separación de tráfico, carriles, áreas de precaución, área a evitar y área de fondeo."

### SRC-181 — Centro de Control de Tráfico Marítimo: Información General CCTM

- Authority: ASIPONA Veracruz.
- URL: https://www.puertodeveracruz.com.mx/infraestructura/centro-de-control-de-trafico-maritimo/informacion-general-cctm/
- Evidence class: Tier 2.
- Edition or date: Undated web page (accessed 2026-09-29).
- Accessed: 29 September 2026.
- Use (B41): Sea buoy position, pilot boarding, Capitanía de Puerto listening watch on VHF 12.
- Locator: Información General CCTM.
- Passage: "La Capitanía de Puerto está a la escucha en canal VHF 12."

### SRC-182 — data/authoritative/IMO_2025_Mandatory_Reporting_Systems.csv

- Authority: Global VTS project (IMO Ships' Routeing 2025 Edition, Part I).
- URL: repository file
- Evidence class: Tier 1.
- Edition or date: Ships' Routeing 2025 Edition baseline.
- Accessed: 29 September 2026.
- Use (B39): The 23 IMO-adopted mandatory ship reporting systems include none for Peru, Chile or Canada (nearest: VRS-0019 GALREP, Ecuador)
- Locator: rows VRS-0001 to VRS-0023.
- Passage: "I-I/19,In the Galapagos Particularly Sensitive Sea Area [GALREP],...,VRS-0019"

### SRC-183 — data/authoritative/IMO_2025_Mandatory_Reporting_Systems.csv

- Authority: Global VTS project (IMO Ships' Routeing 2025 Edition, Part I).
- URL: repository file
- Evidence class: Tier 1.
- Edition or date: Ships' Routeing 2025 Edition baseline.
- Accessed: 29 September 2026.
- Use (B38): The 23 IMO-adopted mandatory ship reporting systems include none for Peru, Chile or Canada (nearest: VRS-0019 GALREP, Ecuador)
- Locator: rows VRS-0001 to VRS-0023.
- Passage: "I-I/19,In the Galapagos Particularly Sensitive Sea Area [GALREP],...,VRS-0019"

### SRC-184 — data/authoritative/IMO_2025_Mandatory_Reporting_Systems.csv

- Authority: Global VTS project (IMO Ships' Routeing 2025 Edition, Part I).
- URL: repository file
- Evidence class: Tier 1.
- Edition or date: Ships' Routeing 2025 Edition baseline.
- Accessed: 29 September 2026.
- Use (B39): The 23 IMO-adopted mandatory ship reporting systems include none for Peru, Chile or Canada (nearest: VRS-0019 GALREP, Ecuador)
- Locator: rows VRS-0001 to VRS-0023.
- Passage: "I-I/19,In the Galapagos Particularly Sensitive Sea Area [GALREP],...,VRS-0019"

### SRC-004 — Channel VTS, Dover Strait

- Authority: UK Maritime and Coastguard Agency.
- URL: https://www.gov.uk/government/publications/dover-strait-crossings-channel-navigation-information-service/dover-strait-crossings-channel-navigation-information-service-cnis
- Evidence class: Primary operating-authority source.
- Updated: 1 February 2024.
- Accessed: 30 September 2026.
- Use: Current Channel VTS operation, joint Dover/Gris-Nez centres and CALDOVREP service area.

### SRC-005 — MGN 364 (M+F) Amendment 2

- Authority: UK Maritime and Coastguard Agency.
- URL: https://www.gov.uk/government/publications/mgn-364-mf-amendment-2-navigation-safety-traffic-separation-schemes-application-of-rule-10-and-navigation-in-the-dover-strait/mgn-364-mf-amendment-2-navigation-safety-traffic-separation-schemes-application-of-rule-10-and-navigation-in-the-dover-strait
- Evidence class: Primary national navigation guidance.
- Accessed: 30 September 2026.
- Use: Direct association between Dover Strait TSS, Channel VTS and CALDOVREP.


### SRC-185 — CROSS Corsen Bilan d'activité 2024

- Authority: Préfecture maritime de l'Atlantique / CROSS Corsen.
- URL: https://www.premar-atlantique.gouv.fr/uploads/atlantique/pages/0aeb0352c8045036ca019e9377ee98fa.pdf
- Evidence class: Primary current operational report.
- Published: 2026.
- Accessed: 30 September 2026.
- Use: Defines the coastal VTS mission of Ouessant Traffic in the Ouessant TSS and records mandatory vessel reports received during 2024.

### SRC-186 — CROSS Jobourg VTS designation and Casquets scope

- Authority: French maritime administration / CROSS Jobourg.
- URL: https://www.premar-manche.gouv.fr/uploads/manche/pages/docs-ocr/bilan-2014/cross_jobourg_-_bilan_operationnel_2014_janvier_2015_-2.pdf
- Evidence class: Primary official VTS description.
- Accessed: 30 September 2026.
- Use: Explicitly designates CROSS Jobourg as the VTS for the Casquets TSS and adjacent coastal area and identifies its operation of the mandatory reporting system.

### SRC-187 — Current CROSS Jobourg Casquets operational evidence

- Authority: Préfecture maritime de la Manche et de la mer du Nord.
- URL: https://www.premar-manche.gouv.fr/communiques-presse/operation-d-assistance-a-un-navire-en-difficulte-au-niveau-du-cap-de-la-hague
- Evidence class: Primary current operational source.
- Published: 9 January 2026.
- Accessed: 30 September 2026.
- Use: Confirms CROSS Jobourg continues active radar/traffic monitoring of commercial vessels in the Casquets routeing area.

### SRC-188 — PLA Tide Booklet 2026

- Authority: Port of London Authority.
- URL: https://pla.co.uk/sites/default/files/2025-12/PLA-Tide-Booklet-2026.pdf
- Evidence class: Primary port-authority navigational publication.
- Edition: 2026.
- Accessed: 30 September 2026.
- Use: States that Sunk VTS covers the Sunk Inner Precautionary Area and TSS and is run by the MCA from CNIS Dover.

### SRC-189 — MCA Sea Link response, April 2026

- Authority: UK Maritime and Coastguard Agency.
- URL: https://nsip-documents.planninginspectorate.gov.uk/published-documents/EN020026-003122-MCA%20Sea%20Link%20Deadline%206%20response%20Cover%20Letter.pdf
- Evidence class: Primary current authority submission.
- Date: 13 April 2026.
- Accessed: 30 September 2026.
- Use: Confirms MCA is the National Competent Authority for Sunk VTS and HM Coastguard is responsible for day-to-day operation.

### SRC-190 — VTS-Scheldt VHF Procedures, version 7.3

- Authority: VTS-Scheldt / Common Nautical Management.
- URL: https://www.vts-scheldt.net/download/d72c012e-266f-4fe4-8412-640b6485834e?dl=0
- Evidence class: Primary operational VTS publication.
- Edition: July 2025.
- Accessed: 30 September 2026.
- Use: Current VHF-sector limits in the Scheldt approaches. Used to test, but not assert, a West Hinder TSS-to-VTS relationship.

### SRC-191 — Netherlands Notice 41/261(P)/25: VTS Off Texel

- Authority: Netherlands Hydrographic Service; reproduced in UKHO Weekly Edition 44 of 2025.
- URL: https://msi.admiralty.co.uk/NoticesToMariners/DownloadFile?batchId=fbeae6b4-4204-4a74-bf85-b699fa8be8b5&fileName=44snii25.pdf&frequency=Weekly&mimeType=application%2Fpdf
- Evidence class: Primary official navigational notice through UKHO.
- Effective date: 3 November 2025 at 14:00 CET.
- Accessed: 30 September 2026.
- Use: Exact polygon of VTS Off Texel, VHF 63 and stated purpose of providing VTS in the TSS off Texel and Vlieland.

### SRC-192 — Rijkswaterstaat Verkeerscentrale Den Helder

- Authority: Rijkswaterstaat.
- URL: https://www.rijkswaterstaat.nl/over-ons/onze-organisatie/organisatiestructuur/verkeer-en-watermanagement/verkeerscentrale-den-helder
- Evidence class: Primary current operating-authority source.
- Accessed: 30 September 2026.
- Use: Confirms current operation of two traffic-service areas from Den Helder: VTS Den Helder on VHF 62 and VTS Off Texel on VHF 63.

### SRC-193 — Rijkswaterstaat current VTS centres dataset

- Authority: Rijkswaterstaat / Fairway Information Services geodata.
- URL: https://geo.rijkswaterstaat.nl/services/ogc/gdr/fis_vnds/ogc/features/v1/collections/vts_centrales/items?f=text%2Fhtml&limit=25
- Evidence class: Primary current government geodata.
- Accessed: 30 September 2026.
- Use: Current Dutch VTS-centre inventory, including Den Helder, IJmuiden, Rotterdam, Scheveningen and Scheldt-related centres. Used with exact VTS-area boundaries rather than as sole evidence of absence.
