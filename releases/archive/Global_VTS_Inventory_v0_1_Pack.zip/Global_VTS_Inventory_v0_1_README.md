# Global VTS guide: working inventory

Version: 0.1  
Created: 29 September 2026  
Status: Provisional research inventory. Not for operational navigation.

## What is recorded

| Register | Records |
|---|---:|
| Candidate TSS source entries | 170 |
| Editorial geographical groups | 17 |
| Named VTS service records | 8 |
| Named reporting systems | 7 |
| Entity relationships | 25 |
| Sources and source leads | 16 |
| Open research issues | 14 |
| Five-record research batches | 34 |

Identification screening has started on 17 TSS records. Five have initial authority-supported associations.
Eight have system-level links only. Four have proposed associations requiring confirmation.
No TSS record or batch is marked fully audited.

These are register counts, not worldwide scheme or operational-area totals.

## Baseline provenance

The candidate labels were extracted from a UKHO-labelled Notice 17 reproduction on a third-party host.
The reproduction's edition and currency remain unverified. It is retained as SRC-001 for identification leads only.
The official UKHO 2026 index was checked, but its linked Notice 17 PDF could not be retrieved.
The IMO Ships’ Routeing 2025 product metadata was checked. Full Part B and reporting-system content were not accessed.
Neither Derek's source PDF nor Sarah's history document was available as a usable input.

The official baseline must be reconciled before completeness is claimed.
Subsequent amendments must then be applied through the agreed cut-off date.
This release does not establish the number of nationally adopted TSS.

## Counting controls

A source entry can contain several schemes. Norway, Åland, Kattegat and other grouped entries are flagged.
Conversely, several source segments can belong to one reporting system.
VTS services, centres, sectors, reporting systems and guide entries remain separate entities.
No final operational-area count, guide-entry count or page estimate is assigned.

Channel VTS is recorded as one joint service, with Dover and Gris-Nez operating centres.
STRAITREP has one scheme record linked to three named VTS authorities.
GOFREP traffic centres are not automatically treated as separate VTS areas.
REEFVTS and Fehmarnbelt are additional-coverage records, not extra TSS entries.
Fehmarnbelt is identified as temporary and voluntary, not as a mandatory reporting system.

## Files

The Excel workbook contains nine sheets:
Overview, TSS Candidates, VTS Services, Reporting Schemes, Relationships, Sources, Issues, Batches and Definitions.

CSV files provide the underlying registers. The JSON file retains all registers for later processing.
Every researched entry carries source identifiers and URLs.
Proposed and system-level relationships are distinguished from authority-supported associations.

## Regional source-entry counts

| Editorial region | Candidate source entries |
|---|---:|
| British Isles and southern North Sea | 16 |
| Norway and Iceland | 3 |
| Baltic Sea and approaches | 26 |
| North Sea continental coast | 13 |
| France, Iberia and Canary Islands | 7 |
| Mediterranean and Black Seas | 24 |
| Southern Africa | 2 |
| Red Sea and Arabian region | 14 |
| Indian Ocean and South Asia | 1 |
| Malacca, Singapore and Indonesia | 10 |
| China Sea and China | 4 |
| North-west Pacific | 5 |
| Australia | 3 |
| North America Pacific coast | 6 |
| Central and South America Pacific coast | 17 |
| Caribbean, Gulf of Mexico and Panama | 10 |
| North America Atlantic coast | 9 |

## Next research step

Reconcile the primary baseline first. Then verify the register in sequential five-record batches.
For each candidate, establish current identity, VTS coverage, reporting scheme and evidence of the relationship.
Resolve grouped records, duplicate names and non-TSS coverage gaps before calculating final totals.

## Review limits

Search access dates do not guarantee that a webpage includes every current amendment.
No confirmed absence of a VTS or reporting scheme has been recorded.
The file contains no approved operational channels, reporting lines, coordinates or passage instructions.
